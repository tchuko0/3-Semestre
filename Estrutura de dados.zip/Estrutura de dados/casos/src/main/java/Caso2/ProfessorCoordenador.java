package Caso2;

public class ProfessorCoordenador extends Professor{

    private Integer qtdHHorasCoodPorSem;
    private Double valorHoraCood;

    public ProfessorCoordenador(String nome, Integer qtdHorasAula, Double valorHoraAula, Integer qtdHHorasCoodPorSem, Double valorHoraCood) {
        super(nome, qtdHorasAula, valorHoraAula);
        this.qtdHHorasCoodPorSem = qtdHHorasCoodPorSem;
        this.valorHoraCood = valorHoraCood;
    }

    public Integer getQtdHHorasCoodPorSem() {
        return qtdHHorasCoodPorSem;
    }

    public void setQtdHHorasCoodPorSem(Integer qtdHHorasCoodPorSem) {
        this.qtdHHorasCoodPorSem = qtdHHorasCoodPorSem;
    }

    public Double getValorHoraCood() {
        return valorHoraCood;
    }

    public void setValorHoraCood(Double valorHoraCood) {
        this.valorHoraCood = valorHoraCood;
    }

    @Override
    public Double getValorBonus() {
        Double valorCoord = 0.0;
        valorCoord = getQtdHHorasCoodPorSem() * getValorHoraCood()*4.5 *0.2;
        return (getQtdAulasSem() * getValorHoraAula()* 4.5) * 0.15 + valorCoord;
    }

    @Override
    public String toString() {
        return "ProfessorCoordenador{" +
                "qtdHHorasCoodPorSem=" + qtdHHorasCoodPorSem +
                ", valorHoraCood=" + valorHoraCood +
                "Valores=" +
                "} " + super.toString();
    }
}
