package Caso2;

public class App {

    public static void main(String[] args) {

        Professor pr = new Professor("Robson",10,10.0);
        ProfessorCoordenador prc =new ProfessorCoordenador("Karen",10,30.0,50,100.0);

        ControleBonus cb = new ControleBonus();

        cb.adicionarBonus(pr);
        cb.adicionarBonus(prc);

        System.out.println(cb.calcTotal());

        cb.exibirTodos();
    }
}
