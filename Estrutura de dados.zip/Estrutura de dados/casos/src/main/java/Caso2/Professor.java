package Caso2;

public class Professor extends Educadores {


    public Professor(String nome, Integer qtdHorasAula, Double valorHoraAula) {
        super(nome, qtdHorasAula, valorHoraAula);
    }

    @Override
    public Double getValorBonus() {
        return (getQtdAulasSem() * getValorHoraAula()* 4.5) * 0.15;
    }

    @Override
    public String toString() {

        return "Professor{} " + "Valores = "+ getValorBonus() +
                super.toString();
    }
}
