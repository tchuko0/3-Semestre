package Caso2;

import java.util.ArrayList;
import java.util.List;

public class ControleBonus {

    private List<Educadores> educadoresList;

    public ControleBonus() {
        this.educadoresList = new ArrayList<>();
    }

    public void adicionarBonus(Educadores educadores){
        educadoresList.add(educadores);
    }

    public Double calcTotal(){
        Double total = 0.0;
        for (Educadores educadores:educadoresList){
            total += educadores.getValorBonus();
        }
        return total;
    }

    public void exibirTodos(){
        for (Educadores educadores:educadoresList){
            System.out.println(educadores);
        }
    }
}
