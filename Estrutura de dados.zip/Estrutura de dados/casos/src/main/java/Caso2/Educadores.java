package Caso2;

public abstract class Educadores {

    private String nome;
    private Integer qtdAulasSem ;
    private Double valorHoraAula;

    public Educadores(String nome, Integer qtdAulasSem, Double valorHoraAula) {
        this.nome = nome;
        this.qtdAulasSem = qtdAulasSem;
        this.valorHoraAula = valorHoraAula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getQtdAulasSem() {
        return qtdAulasSem;
    }

    public void setQtdAulasSem(Integer qtdAulasSem) {
        this.qtdAulasSem = qtdAulasSem;
    }

    public Double getValorHoraAula() {
        return valorHoraAula;
    }

    public void setValorHoraAula(Double valorHoraAula) {
        this.valorHoraAula = valorHoraAula;
    }

    public abstract Double getValorBonus();

    @Override
    public String toString() {
        return "Educadores{" +
                "nome='" + nome + '\'' +
                ", qtdAulasSem=" + qtdAulasSem +
                ", valorHoraAula=" + valorHoraAula +
                '}';
    }
}



