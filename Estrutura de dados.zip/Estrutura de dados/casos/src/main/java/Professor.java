public class Professor implements Bonificavel{


    private String nomeProf;
    private Integer qtdAulasPorSemana;
    private Double valorHoraAula;

    public Professor(String nomeProf, Integer qtdAulasPorSemana, Double valorHoraAula) {
        this.nomeProf = nomeProf;
        this.qtdAulasPorSemana = qtdAulasPorSemana;
        this.valorHoraAula = valorHoraAula;
    }

    public String getNomeProf() {
        return nomeProf;
    }

    public void setNomeProf(String nomeProf) {
        this.nomeProf = nomeProf;
    }

    public Integer getQtdAulasPorSemana() {
        return qtdAulasPorSemana;
    }

    public void setQtdAulasPorSemana(Integer qtdAulasPorSemana) {
        this.qtdAulasPorSemana = qtdAulasPorSemana;
    }

    public Double getValorHoraAula() {
        return valorHoraAula;
    }

    public void setValorHoraAula(Double valorHoraAula) {
        this.valorHoraAula = valorHoraAula;
    }

    @Override
    public Double getValorBonificavel() {
        return (getQtdAulasPorSemana() * getValorHoraAula() * 4.5) * 0.15;
    }

    @Override
    public String toString() {
        return "Professor{" +
                "nomeProf='" + nomeProf + '\'' +
                ", qtdAulasPorSemana=" + qtdAulasPorSemana +
                ", valor=" + getValorBonificavel() +
                ", valorHoraAula=" + valorHoraAula +
                '}';
    }
}
