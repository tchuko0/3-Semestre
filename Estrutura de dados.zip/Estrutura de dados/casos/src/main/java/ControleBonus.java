import java.util.ArrayList;
import java.util.List;

public class ControleBonus {

    private List<Bonificavel>bonificavelList;

    public ControleBonus() {

        this.bonificavelList = new ArrayList<>();
    }

    public void adicionarFunc(Bonificavel bonificavel){
        bonificavelList.add(bonificavel);
    }

    public Double CalcularTotalValor(){

    Double total = 0.0;

        for (Bonificavel b : bonificavelList){
            total +=b.getValorBonificavel();
        }

        return total;
    }

    public void exibirTodos(){
        for (Bonificavel b: bonificavelList){
            System.out.println(b);
        }
    }
}
