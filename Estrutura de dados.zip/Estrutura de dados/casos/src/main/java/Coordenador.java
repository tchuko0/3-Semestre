public class Coordenador implements Bonificavel{

    private String nomeCood;
    private Integer qtdHorasCoodPorSem;
    private Double valorHoraCood;

    public Coordenador(String nomeCood, Integer qtdHorasCoodPorSem, Double valorHoraCood) {
        this.nomeCood = nomeCood;
        this.qtdHorasCoodPorSem = qtdHorasCoodPorSem;
        this.valorHoraCood = valorHoraCood;
    }

    public String getNomeCood() {
        return nomeCood;
    }

    public void setNomeCood(String nomeCood) {
        this.nomeCood = nomeCood;
    }

    public Integer getQtdHorasCoodPorSem() {
        return qtdHorasCoodPorSem;
    }

    public void setQtdHorasCoodPorSem(Integer qtdHorasCoodPorSem) {
        this.qtdHorasCoodPorSem = qtdHorasCoodPorSem;
    }

    public Double getValorHoraCood() {
        return valorHoraCood;
    }

    public void setValorHoraCood(Double valorHoraCood) {
        this.valorHoraCood = valorHoraCood;
    }

    @Override
    public Double getValorBonificavel() {

        return (getValorHoraCood() * getValorHoraCood() * 4.5) * 0.2;
    }

    @Override
    public String toString() {
        return "Coordenador{" +
                "nomeCood='" + nomeCood + '\'' +
                ", qtdHorasCoodPorSem=" + qtdHorasCoodPorSem +
                ", valor =" + getValorBonificavel() +
                ", valorHoraCood=" + valorHoraCood +
                '}';
    }
}
