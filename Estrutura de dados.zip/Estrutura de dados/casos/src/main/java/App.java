public class App {

    public static void main(String[] args) {

        Professor p = new Professor("Dener",10,80.0);
        Coordenador c = new Coordenador("Robson",40,70.0);

        ControleBonus cb = new ControleBonus();

        cb.adicionarFunc(p);
        cb.adicionarFunc(c);

        System.out.println(cb.CalcularTotalValor());

        cb.exibirTodos();

    }
}
