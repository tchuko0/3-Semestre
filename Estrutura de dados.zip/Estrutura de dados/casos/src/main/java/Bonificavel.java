public interface Bonificavel {

    public Double getValorBonificavel();

}
