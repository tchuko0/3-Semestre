public class App {

    public static void main(String[] args) {

        Economica ec = new Economica("Maré",400.0,"Argentina","454");
        Vip vp = new Vip("Maré",1200.0,"Argentina","003");
        Bagagem bg = new Bagagem(11.1,2);
        Bagagem bga = new Bagagem(10.0,1);


        AgenciaViagem ag = new AgenciaViagem("Viagem dos sonhos");

    ag.adcViagem(vp);
    ag.adcViagem(ec);
    ag.adcViagem(bg);
    ag.adcViagem(bga);


    System.out.println(ag.valorTotal());

    ag.exibirTodos();

    }
}
