public class Bagagem implements IDesconto {

    private Double peso;
    private Integer quantidadeDeBg;

    public Bagagem(Double peso, Integer quantidadeDeBg) {
        this.peso = peso;
        this.quantidadeDeBg = quantidadeDeBg;
    }

    public Double getPeso() {

        return peso;
    }


    public void setPeso(Double peso) {
        this.peso = peso;
    }

    public Integer getQuantidadeDeBg() {
        return quantidadeDeBg;
    }

    public void setQuantidadeDeBg(Integer quantidadeDeBg) {
        this.quantidadeDeBg = quantidadeDeBg;
    }

    public Double getPesoFinal() {
        if (peso > 10 && quantidadeDeBg > 1) {
            return peso + (peso * 0.9);
        }
        return peso;
    }

    @Override
    public Double getValorDesconto() {
        return getPesoFinal();
    }

    @Override
    public String toString() {
        return "Bagagem{" +
                "peso=" + peso +
                ", quantidadeDeBg=" + quantidadeDeBg +
                ",Valor=" + getPesoFinal() +
                '}';
    }
}
