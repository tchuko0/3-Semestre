public abstract class ViagemNavio implements IDesconto {

    private String companhia;
    private Double preco;
    private String destino;
    private String cabine;

    public ViagemNavio(String companhia, Double preco, String destino, String cabine) {
        this.companhia = companhia;
        this.preco = preco;
        this.destino = destino;
        this.cabine = cabine;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }


    @Override
    public String toString() {
        return "ViagemNavio{" +
                "companhia='" + companhia + '\'' +
                ", preco=" + preco +
                ", destino='" + destino + '\'' +
                ", cabine='" + cabine + '\'' +
                ", valores=" + getValorDesconto()+
                '}';
    }
}
