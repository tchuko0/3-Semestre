public class Economica extends ViagemNavio{
    public Economica(String companhia, Double preco, String destino, String cabine) {
        super(companhia, preco, destino, cabine);
    }


    @Override
    public Double getValorDesconto() {
        return getPreco() + (getPreco() * 0.1);
    }

    @Override
    public String toString() {
        return "Economica{} " + super.toString();
    }
}
