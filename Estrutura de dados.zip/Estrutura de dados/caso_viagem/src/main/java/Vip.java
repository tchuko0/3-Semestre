public class Vip extends ViagemNavio{
    public Vip(String companhia, Double preco, String destino, String cabine) {
        super(companhia, preco, destino, cabine);
    }

    @Override
    public Double getValorDesconto() {
        return getPreco()+ (getPreco() * 0.7);
    }

    @Override
    public String toString() {
        return "Vip{} " + super.toString();
    }
}
