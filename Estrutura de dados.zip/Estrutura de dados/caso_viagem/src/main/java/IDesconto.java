public interface IDesconto {

    public Double getValorDesconto();

}
