import java.util.ArrayList;
import java.util.List;

public class AgenciaViagem {

    private String nome;
    private List<IDesconto> iDescontoList;

    public AgenciaViagem(String nome) {

        this.iDescontoList = new ArrayList<>();

    }

    public void adcViagem(IDesconto iDesconto){

        iDescontoList.add(iDesconto);

    }

    public Double valorTotal(){

        Double total = 0.0;

        for (IDesconto iDescontoNavio : iDescontoList){
            total += iDescontoNavio.getValorDesconto();
        }
        return total;

    }

    public void exibirTodos(){

        for (IDesconto iDescontoNavio:iDescontoList){
            System.out.println(iDescontoNavio);
        }
    }
}
