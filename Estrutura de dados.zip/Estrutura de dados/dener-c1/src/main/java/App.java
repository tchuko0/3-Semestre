public class App {

    public static void main(String[] args) {

        MedicoClinico clinico =new MedicoClinico("1111","dener",10,200.0);
        MedicoCirurgiao cirurgiao = new MedicoCirurgiao("2222","diego",3,1000.0,500.0);

        Acionista acionista = new Acionista( "Robson",40,80.0);

        ControleBonus controleBonus = new ControleBonus();

        controleBonus.adcionarBonificavel(clinico);
        controleBonus.adcionarBonificavel(cirurgiao);
        controleBonus.adcionarBonificavel(acionista);



        controleBonus.CalcularTotalBonus();

        controleBonus.exibirTodos();


    }

}
