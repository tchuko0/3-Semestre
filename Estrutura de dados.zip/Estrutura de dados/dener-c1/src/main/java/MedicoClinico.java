public class MedicoClinico extends Medicos{


    private Integer qtdConsulta;
    private Double valorConsulta;

    public MedicoClinico(String crm, String nome, Integer qtdConsulta, Double valorConsulta) {
        super(crm, nome);
        this.qtdConsulta = qtdConsulta;
        this.valorConsulta = valorConsulta;
    }

    public Integer getQtdConsulta() {
        return qtdConsulta;
    }

    public void setQtdConsulta(Integer qtdConsulta) {
        this.qtdConsulta = qtdConsulta;
    }

    public Double getValorConsulta() {
        return valorConsulta;
    }

    public void setValorConsulta(Double valorConsulta) {
        this.valorConsulta = valorConsulta;
    }

    public Double getGanho(){

        return getQtdConsulta() + (getQtdConsulta() * getValorConsulta());
    }

    @Override
    public Double getValorBonus() {
        return getGanho() * 0.1;
    }

    @Override
    public String toString() {
        return "MedicoClinico{" +
                "qtdConsulta=" + qtdConsulta +
                ", valorConsulta=" + valorConsulta +
                " valor consulta" + getValorBonus() +
                "} " + super.toString();
    }
}
