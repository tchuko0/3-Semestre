public class MedicoCirurgiao extends Medicos{

    private Integer qtdCirurgia;
    private Double valorCirurgia;

    private Double velorAnestesia;


    public MedicoCirurgiao(String crm, String nome, Integer qtdCirurgia, Double valorCirurgia, Double velorAnestesia) {
        super(crm, nome);
        this.qtdCirurgia = qtdCirurgia;
        this.valorCirurgia = valorCirurgia;
        this.velorAnestesia = velorAnestesia;
    }

    public Integer getQtdCirurgia() {
        return qtdCirurgia;
    }

    public void setQtdCirurgia(Integer qtdCirurgia) {
        this.qtdCirurgia = qtdCirurgia;
    }

    public Double getValorCirurgia() {
        return valorCirurgia;
    }

    public void setValorCirurgia(Double valorCirurgia) {
        this.valorCirurgia = valorCirurgia;
    }

    public Double getVelorAnestesia() {
        return velorAnestesia;
    }

    public void setVelorAnestesia(Double velorAnestesia) {
        this.velorAnestesia = velorAnestesia;
    }

    public Double getGanho(){

        return getQtdCirurgia() + (getValorCirurgia() * getVelorAnestesia());
    }
    @Override
    public Double getValorBonus() {
        return getGanho() * 0.15;
    }

    @Override
    public String toString() {
        return "MedicoCirurgiao{" +
                "qtdCirurgia=" + qtdCirurgia +
                ", valorCirurgia=" + valorCirurgia +
                "Valor cirurgia" + getValorBonus() +
                "} " + super.toString();
    }
}
