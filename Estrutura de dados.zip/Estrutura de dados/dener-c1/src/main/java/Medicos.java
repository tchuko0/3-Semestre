public abstract class Medicos implements Bonificavel {

    private String crm;
    private String nome;

    public Medicos(String crm, String nome) {
        this.crm = crm;
        this.nome = nome;
    }

    public String getCrm() {
        return crm;
    }

    public void setCrm(String crm) {
        this.crm = crm;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Medicos{" +
                "crm='" + crm + '\'' +
                ", nome='" + nome + '\'' +
                '}';
    }
}
