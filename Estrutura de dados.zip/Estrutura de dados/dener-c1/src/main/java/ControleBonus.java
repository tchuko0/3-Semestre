import java.util.ArrayList;
import java.util.List;

public class ControleBonus {

    private List<Bonificavel> bonificavelList;

    public ControleBonus() {
        this.bonificavelList = new ArrayList<>();
    }

    public void adcionarBonificavel(Bonificavel bonificavel) {

        bonificavelList.add(bonificavel);
    }

    public Double CalcularTotalBonus() {

        Double total = 0.0;

        for (Bonificavel bonificavel : bonificavelList) {
            total += bonificavel.getValorBonus();
        }

        return total;
    }

    public void exibirTodos() {

        for (Bonificavel bonificavel : bonificavelList) {
            System.out.println(bonificavel);
        }

    }

}

