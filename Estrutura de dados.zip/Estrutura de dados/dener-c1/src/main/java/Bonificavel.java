public interface Bonificavel {

    public Double getValorBonus();
}
