import java.text.Format;
import java.util.ArrayList;
import java.util.List;

public class Escola {

    private String nome;
    private List<Aluno> al;

    public Escola(String nome) {
        this.nome = nome;
        this.al = new ArrayList<>();
    }

    public void adicionarAluno(Aluno aluno) {

        al.add(aluno);

    }

    public void exibirTodos() {

        System.out.println(al);

    }

    public void exibirAlunosGraduacao() {

        for (Integer i = 0; i < al.size(); i++) {
            if (al.get(i) instanceof AlunoGraduacao) {
                System.out.println(al.get(i));
            }
        }


    }


    public void exibirAprovados() {

        for (Aluno aluno : al) {
            if (aluno.calcularMedia() >= 6) {
                System.out.println(String.format("Aluno %s Aprovados .. PARABENS", aluno));
            }

        }


    }

    public void buscarAluno(Integer ra) {

        Boolean existe = false;

        for (Aluno aluno : al) {
            if (aluno.getRa().equals(ra)) {
                System.out.println(aluno);
                existe = true;
            }
        }
        if (!existe) {
            System.out.println("Nâo encontrou");
        }
    }

}
