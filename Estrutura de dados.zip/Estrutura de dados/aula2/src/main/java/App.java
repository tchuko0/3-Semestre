public class App {

    public static void main(String[] args) {

        // Instacia de Aluno

    AlunoFundamental af = new AlunoFundamental(12345,"Dener",10.0,7.6,7.9,9.5);

    AlunoGraduacao ag = new AlunoGraduacao(101112,"Karen",10.0,6.8);

    AlunoPos ap = new AlunoPos(405060,"Robson",0.0,0.0,0.0);

       // Instancia de Escola

    Escola es = new Escola("Mariuma");

      // Adicionando Alunos

        es.adicionarAluno(af);
        es.adicionarAluno(ag);
        es.adicionarAluno(ap);

      // Exibindo Alunos

        es.exibirTodos();

      // Exibindo Alunos Graduação

        es.exibirAlunosGraduacao();

      // Exibindo alunos aprovados

        es.exibirAprovados();

      // Buscando aluno por ra

        es.buscarAluno(12345);


    }
}
