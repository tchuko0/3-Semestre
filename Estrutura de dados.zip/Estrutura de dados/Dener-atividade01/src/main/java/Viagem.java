public class Viagem {

    private Integer id;
    private Integer qtdPassagem;
    private String local;
    private Double Valor;
    private String cabine;
    private String nome;

    public Viagem(Integer id, Integer qtdPassagem, String local, Double valor, String cabine, String classe) {
        this.id = id;
        this.qtdPassagem = qtdPassagem;
        this.local = local;
        Valor = valor;
        this.cabine = cabine;
        this.nome = classe;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getQtdPassagem() {
        return qtdPassagem;
    }

    public void setQtdPassagem(Integer qtdPassagem) {
        this.qtdPassagem = qtdPassagem;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public Double getValor() {
        return Valor;
    }

    public void setValor(Double valor) {
        Valor = valor;
    }

    public String getCabine() {
        return cabine;
    }

    public void setCabine(String cabine) {
        this.cabine = cabine;
    }

    public String getNome() {
        return nome;
    }



    public void setClasse(String classe) {
        this.nome = classe;
    }


    @Override
    public String toString() {
        return "Viagem{" +
                "id=" + id +
                ", qtdPassagem=" + qtdPassagem +
                ", local='" + local + '\'' +
                ", Valor=" + Valor +
                ", cabine='" + cabine + '\'' +
                ", classe='" + nome + '\'' +
                '}';
    }
}
