import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class ArqCsv {
    public static void gravaArquivoCsv(ListaObj<Viagem> lista, String nomeArq){

        FileWriter arq = null; // objeto que representa o arquivo de escrita
        Formatter saida = null; // objeto usado para escrever no arquivo
        Boolean deuRuim = false;
        nomeArq+=".csv"; // acrecenta a extensão csv ao nome do arquivo

        try {
            arq = new FileWriter(nomeArq,true);

            saida = new Formatter(arq);
        }
        catch (IOException e){
            System.out.println("Erro ao abrir o arquivo");
            System.exit(1);
        }
        try {
            for (int i =0; i< lista.getTamanho();i++){
                Viagem v = lista.getElemento(i);
                saida.format("%d;%s;%.2f;%d;%s;%s\n",v.getId(),v.getNome(), v.getValor(),v.getQtdPassagem(),v.getLocal(),v.getCabine());
            }

        }
        catch (FormatterClosedException e){
            System.out.println("Erro ao gravar ao arquivo");
            deuRuim = true;
        }
        finally {
            saida.close();
            try {
                arq.close();
            }
            catch (IOException e){
                System.out.println("erro ao fechar o arquivo");
                deuRuim = true;
            }

            if (deuRuim){
                System.exit(1);
            }

        }
    }

    public static void leExibeArquivoCsv(String nomeArq){
        FileReader arq = null; // representa o arquivo para leitura
        Scanner entrada = null; // objeto usando para ler o arquivo
        Boolean deuRuim = false;
        nomeArq += ".csv";

        try {
            arq = new FileReader(nomeArq);
            entrada = new Scanner(arq).useDelimiter(";|\\n");
        }
        catch (FileNotFoundException e){
            System.out.println("Arquivo não encontrado");
            System.exit(1);
        }

        // bloco para ler o arquivo

        try {
            System.out.printf("%-6s %6s %-6s %-9s %-6s %-6s \n", "CÓDIGO", "NOME", "VALOR", "PASSAGENS","LOCAL","CABINE");

            while (entrada.hasNext()){
                Integer id = entrada.nextInt();
                String nome = entrada.next();
                Double valor = entrada.nextDouble();
                Integer QtdPassagem = entrada.nextInt();
                String local = entrada.next();
                String cabine = entrada.next();

                System.out.printf("%06d %-8s %6.2f %5d %-6s %-6s \n", id,nome, valor,QtdPassagem,local,cabine);
            }
        }
        catch (NoSuchElementException e){
            System.out.println("Arquivo com problema");
            deuRuim = true;
        }
        catch (IllegalStateException e){
            System.out.println("Erro na leitura do arquivo");
            deuRuim = true;
        }
        finally {
            try {
                arq.close();
            }
            catch (IOException e){
                System.out.println("erro ao fechar o arquivo");
                deuRuim = true;
            }

            if (deuRuim){
                System.exit(1);
            }

        }

    }

}
