import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.Scanner;

public class Teste {
    public static void main(String[] args) {
        Integer opcao = 0;
        Scanner leitor = new Scanner(System.in);
        Scanner leitorNl = new Scanner(System.in);
        System.out.println("Companhia boa viagem!");

        ListaObj<Viagem> viagemListaObj = new ListaObj<>(10);

        do{
            System.out.println("Escolha a opção desejada: (digite 1, 2 ou 3)");
            System.out.println("1 - Adicionar Viagem");
            System.out.println("2 - Exibir Relatório");
            System.out.println("3 - Gravas arquivo csv");
            System.out.println("4 - ler arquivo csv");
            System.out.println("5 - Sair");
            opcao = leitor.nextInt();

            switch (opcao){
                case 1:
                    System.out.println("Digite o identificador:");
                    int id = leitor.nextInt();

                    System.out.println("Digite o nome:");
                    String nome = leitorNl.nextLine();

                    System.out.println("Digite o valor:");
                    Double valor = leitor.nextDouble();

                    System.out.println("Digite a quantidade de passagem:");
                    int qtdPassagem = leitor.nextInt();

                    System.out.println("Digite o destino:");
                    String local = leitorNl.nextLine();

                    System.out.println("Digite a cabine:");
                    String cabine = leitorNl.nextLine();

                    viagemListaObj.adiciona(new Viagem(id,qtdPassagem,local,valor,cabine,nome));

                    System.out.println("Viagem adicionado!");
                    break;
                case 2:
                    System.out.println("");
                    System.out.printf("%-6s %-3s %6s %9s %-6s %-6s \n", "CÓDIGO", "NOME", "VALOR", "PASSAGENS","LOCAL","CABINE");
                    for (int i = 0; i < viagemListaObj.getTamanho(); i++){
                        Viagem v = viagemListaObj.getElemento(i);
                        System.out.printf("%06d %-3s %6.2f %5d %6s %6s \n", v.getId(),v.getNome(), v.getValor(),v.getQtdPassagem(),v.getLocal(),v.getCabine());
                    }
                    System.out.printf("");
                    break;
                case 3:
                    ArqCsv.gravaArquivoCsv(viagemListaObj,"csv navio");
                    break;
                case 4:
                    ArqCsv.leExibeArquivoCsv("csv navio");
                    break;
                case 5:
                    System.out.println("Obrigada por utilizar :)");
                    break;
                case 6:
                    System.out.println("Atualizar valor :)");
                    for (int i = 0; i < viagemListaObj.getTamanho(); i++){
                        System.out.println("Digite um numero");
                        Double valorAntigo = leitor.nextDouble();
                        System.out.println("Digite um numero");
                        Double novoValor = leitor.nextDouble();
                         Viagem viagem = viagemListaObj.getElemento(i);

                        if (viagemListaObj.getElemento(i).getValor().equals(valorAntigo)){

                        }
                    }

                    break;
                default:
                    System.out.println("Opção digitada inválida");
                    break;
            }
        } while (opcao != 5);
    }
}
