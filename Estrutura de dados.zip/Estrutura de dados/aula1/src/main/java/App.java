public class App {

    public static void main(String[] args) {

        Engenheiro e = new Engenheiro("11111","dener",2000.0);
        Vendedor v = new Vendedor("2222222","diego",20.0,0.4);
        Horista h = new Horista("3333","danilo",20,20.0);

        Empresa empresa = new Empresa("aaa");

        empresa.adicionarFunc(e);
        empresa.adicionarFunc(v);
        empresa.adicionarFunc(h);

        empresa.exibirHoristas();
        empresa.exibirTotalSalario();
        empresa.exibirTodos();
        empresa.removerFunc("diegsss");

        empresa.buscarFunc("9999");
    }
}
