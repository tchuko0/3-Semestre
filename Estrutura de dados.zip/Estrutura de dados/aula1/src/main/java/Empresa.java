import java.util.ArrayList;
import java.util.List;

public class Empresa {

    private String nome;
    private List<Funcionario> func;


    public Empresa(String nome) {
        this.nome = nome;
        this.func = func = new ArrayList<>();
    }

    public void adicionarFunc(Funcionario funcionario) {

        func.add(funcionario);


    }

    public void exibirTodos() {

//        for (Integer i = 0; i < func.size(); i++) {
//        }
        System.out.println(func);

    }

    public void exibirTotalSalario() {

        Double valTotal = 0.0;
        for (Funcionario funcionario : func) {
            valTotal += funcionario.calcularSalario();


        }

        System.out.println(valTotal);

    }

    public void exibirHoristas() {

        for (Integer i = 0; i < func.size(); i++) {
            if (func.get(i) instanceof Horista) {

                System.out.println(func.get(i));

            } else {
                System.out.println("Não encontrou");
            }
        }
    }

    // buscar por cpf e verificar se exiset cpf


    public void buscarFunc(String cpf) {
        Boolean achou = false;
        for (Funcionario funcionario : func) {
            if (funcionario.getCpf().equals(cpf)) {
                System.out.println(funcionario);
                achou = true;

            }

        }
        if (!achou) {
            System.out.println("não encontrou");
        }
    }

    public void removerFunc(String nome){
        Integer contador = 0;
        for (Funcionario funcionario : func){
            if (funcionario.getNome().equals(nome)){

                func.remove(nome);
                contador++;
            }
        }
        System.out.println(contador);
    }


}




