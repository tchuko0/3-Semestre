public class Horista extends Funcionario {

    private Integer qtdHoras;
    private Double valorHora;

    public Horista(String cpf, String nome, Integer qtdHoras, Double valorHora) {
        super(cpf, nome);
        this.qtdHoras = qtdHoras;
        this.valorHora = valorHora;
    }

    public Integer getQtdHoras() {
        return qtdHoras;
    }

    public void setQtdHoras(Integer qtdHoras) {
        this.qtdHoras = qtdHoras;
    }

    public Double getValorHora() {
        return valorHora;
    }

    public void setValorHora(Double valorHora) {
        this.valorHora = valorHora;
    }

    @Override
    public Double calcularSalario() {
        return qtdHoras * valorHora;
    }

    @Override
    public String toString() {
        return "Horista{" +
                "qtdHoras=" + qtdHoras +
                ", valorHora=" + valorHora +
                ",salario =" + calcularSalario() +
                "} " + super.toString();
    }
}
