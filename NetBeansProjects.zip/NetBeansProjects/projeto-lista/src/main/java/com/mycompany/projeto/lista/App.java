/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.lista;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dener.souza
 */
public class App {

    public static void main(String[] args) {

        // Sistaxe padrão para iniciar uma lista;
        List listaEstranha = new ArrayList();

        // o metodo "add" permite adicionar um valor na lista.
//        listaEstranha.add("Dener");
//        listaEstranha.add(20);
//        listaEstranha.add(42.0);
//        listaEstranha.add(true);
//
//        System.out.println(listaEstranha);
        // Sistaxe padrão para iniciar uma lista de texto (tipo generico <tipo>);
        List<String> nomes = new ArrayList();
        nomes.add("Dener");
        nomes.add("Diego");
        nomes.add("Robson");
        nomes.add("Viviane");
//        varrendo uma lista (LEMBRAR DE USAR O SIZE)

//         size() -> retorna quantidade de itens dentro da lista
//         size() -> retorna quantidade de itens dentro da lista
//        for (int i = 0; i < nomes.size(); i++) {
//            System.out.println(nomes.get(i));
//        }
//      for aprimorado (enhanced for)
        for (String nome : nomes) {
            System.out.println("nome: " + nome);
        }
        System.out.println("-".repeat(50));

        nomes.remove(0);

        System.out.println("Depois do remove ");
        System.out.println("-".repeat(50));
        for (String nome : nomes) {
            System.out.println("nome: " + nome);

        }

        nomes.set(0, "Frizza");

        System.out.println("-".repeat(50));
        System.out.println("Depois do set ");

        for (String nome : nomes) {
            System.out.println("nome: " + nome);
        }

        nomes.add(0, "Rogerio");

        System.out.println("-".repeat(50));
        System.out.println("Depois do set ");

        for (String nome : nomes) {
            System.out.println("nome: " + nome);
            

        }
        
        Animacao a1 = new Animacao("Shrek", 2001);
        Animacao a2 = new Animacao("Espanta tubarões", 2005);
        Animacao a3 = new Animacao("Irmão urso", 2003);
        Animacao a4 = new Animacao("Procurando nemo", 2002);
        
        List<Animacao> animacoes = new ArrayList<>();
        
        animacoes.add(a1);
        animacoes.add(a2);
        animacoes.add(a3);
        animacoes.add(a4);
        
        for (Animacao animacao : animacoes) {
            System.out.println(animacao);
        }

    }

}
