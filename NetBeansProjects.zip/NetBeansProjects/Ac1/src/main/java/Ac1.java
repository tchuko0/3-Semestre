
import java.util.Scanner;

public class Ac1 {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Informe a quantidade de produtos em estoque");
        Integer emEstoque = leitor.nextInt();

        System.out.println("Informe a meta de vendas");
        Integer metaVendas = leitor.nextInt();

        Integer baterMeta = (emEstoque * metaVendas) / 100;
        System.out.println(String.format("para atingir a meta você precisa vender %d produtos", baterMeta));

        System.out.println("Escolha o proximo passo");
        System.out.println(metaVendas);

        Integer RespostaUsuario = 0;

        System.out.println("OPÇÕES: \n 1- Realizar Compra"
                + " \n 2- Sair");
        RespostaUsuario = leitor.nextInt();

        switch (RespostaUsuario) {
            case 1:
                System.out.println("Digite a quantidade de produto");
                Integer qtdSolicitada = leitor.nextInt();
                Integer restoEstoque = qtdSolicitada - emEstoque;

                if (qtdSolicitada > emEstoque) {
                    System.out.println(String.format("Infelizamente não temos a quantidade de produtos digitadas \n"
                            + "Quantidade disponivel %d\n"
                            + "digite novamente", emEstoque));

                }

                for (int i = emEstoque; i > qtdSolicitada; i--) {
                    System.out.println(String.format("a venda do produto %d foi registrada e restam %d no estoque ", qtdSolicitada, restoEstoque - 1));
                }

                System.out.println(String.format("voce acabou de ser  vender %d produtos (sua meta é %d)", qtdSolicitada, metaVendas));

                break;
            case 2:
                System.out.println("Até logo...");
                break;
            default:
                System.out.println("Numero invalido");
                break;
        }

    }
}

//       Orientações gerais:
//
//I. Crie 1 (um) projeto Java no NetBeans para implementar o que será solicitado nas questões. Antes de enviá-lo, compacte ele no formato .zip (nenhum outro formato será aceito).
//
//II. O nome do projeto deve ser seunome-seusobrenome-c1. Ex: maria-silva-c1. Provas com nome fora desse padrão terão um desconto de 1,0 pt na nota da prova!
//
//III. Não seguir em pelo menos 1 situação as convenções de nomes de projeto, classe ou variáveis da linguagem Java fará com que a nota tenha uma multa.
//
//IV. Crie dentro do projeto uma classe executável, chamada Loja.
//
//V. Leia atentamente o enunciado até o final antes de começar a programar.
//
//
//Enunciado:
//
//Com aumento de vendas, uma loja decidiu implementar um sistema de controle de vendas e metas, para isso, desenvolva um programa em Java de acordo com os seguintes requisitos:
//
//
//
//1)  Cadastro de estoque
//
//O programa deve perguntar ao usuário a quantidade de produtos em estoque:
//
//
//
//Armazene a quantidade digitada e em seguida, pergunte a meta de venda:
//
//
//
//Calcule a quantidade de produtos que o lojista precisa vender de acordo com a porcentagem fornecida, e em seguida exiba utilizando a interpolação de texto:
//
//
//
//Sendo x, a quantidade de produtos.
//
//Exemplo: supondo que o lojista possua 100 produtos em estoque e sua meta seja vender 60%, ele deve vender 60 produtos.
//
//
//2) Menu de opções
//
//Após realizar o cálculo da meta exiba as seguintes opções:
//
//
//
//Utilize switch-case para validações
//Se o número digitado for 2, exiba "Até logo" e encerre a execução.
//Se o número digitado for diferente de 1 e 2, exiba "Número Inválido" 
//
//
//3) Vender:
//
//Caso o número digitado seja 1, exiba a frase:
//
//
//
//Enquanto o usuário não digitar um número valido de acordo com estoque, exiba utilizando a interpolação de texto:
//
//
//
//
//Sendo x, a quantidade de livros em estoque.
//
//Após o usuário digitar uma quantidade válida, exiba a seguinte mensagem para cada livro vendido utilizando a interpolação de texto:
//
//
//
//
//
//
//Observação:  a frase deve ser exibida para cada produto vendido, exemplo:
//
//Supondo que o lojista tenha 100 produtos em estoque, e a quantidade escolhida para venda seja 3, exiba:
//
//
//
//Por fim, mostre as seguintes mensagens utilizando a interpolação de texto:
//
//
//
//Sendo X o valor digitado para venda, y o valor definido como meta.
//
//
//Exemplo de saída:
//
//
//
//
//
//
//Para atingir nota máxima(10): 
//
//Fazer com que o programa exiba novamente o menu de opções e fique em loop, permitindo que o usuário realize novas vendas, até que escolha a opção Sair(item 2 do menu).
//Melhore a opção 1 do menu de tal forma que, caso o usuário tente vender e o estoque seja 0, exiba o seguinte:
//Operação inválida - estoque zerado!
//        
//
