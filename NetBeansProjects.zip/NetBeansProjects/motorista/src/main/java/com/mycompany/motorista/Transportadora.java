/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.motorista;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dener.souza
 */
public class Transportadora {

    private String nome;
    private Integer vagas;
    private List<Motorista> motorista;

    public Transportadora(String nome, Integer vagas) {
        this.nome = nome;
        this.vagas = vagas;
        this.motorista = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getVagas() {
        return vagas;
    }

    public void setVagas(Integer vagas) {
        this.vagas = vagas;
    }

    public List<Motorista> getMotorista() {
        return motorista;
    }

    public void setMotorista(List<Motorista> motorista) {
        this.motorista = motorista;
    }

    @Override
    public String toString() {
        return "Transportadora{" + "nome=" + nome + ", vagas=" + vagas + ", motorista=" + motorista + '}';
    }

    


    
    

}
