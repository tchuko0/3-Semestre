
package com.mycompany.aula2;


public class Exercicio9 {
    
    public static void main(String[] args) {
        
        for (Double num = 0.15; num <5; num+=0.15) {
            System.out.println( String.format("%.2f", num));
        }
    }
    
}
