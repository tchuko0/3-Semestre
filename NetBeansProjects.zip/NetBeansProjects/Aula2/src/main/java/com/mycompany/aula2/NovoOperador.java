
package com.mycompany.aula2;

public class NovoOperador {
    
    public static void main(String[] args) {
        
        String nome = "Dener";
        Boolean aluno = true;
        
        if (aluno) {
            System.out.println(String.format( "%s é aluno", nome));
        } else {
             System.out.println(String.format( "%s não é aluno", nome));
        }
    }
    
    
    

    
}
