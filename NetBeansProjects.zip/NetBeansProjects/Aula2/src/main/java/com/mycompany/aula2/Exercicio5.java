
package com.mycompany.aula2;

public class Exercicio5 {
    
    public static void main(String[] args) {

            
        Integer cont = 0;
        Integer num = 40;
        
            while (cont <= num) {            
            cont++;
                if (cont %2==0) {
                    System.out.println(cont);
                    
               }
           }

      }
   }
    

