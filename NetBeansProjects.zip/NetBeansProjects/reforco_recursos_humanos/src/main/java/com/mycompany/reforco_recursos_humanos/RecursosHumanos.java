/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.reforco_recursos_humanos;

public class RecursosHumanos {

    private Integer totalPromovidos;
    private Integer totalSalariosReajustados;

    public RecursosHumanos() {
        this.totalPromovidos = 0;
        this.totalSalariosReajustados = 0;
    }

    public void reajustarSalario(Colaborador colaborador, Double reajuste) {
        totalSalariosReajustados++;
        Double valorReajustado = (reajuste / 100) * colaborador.getSalario();
        Double valorComReajuste = colaborador.getSalario() + valorReajustado;
        colaborador.setSalario(valorComReajuste);

    }

    public void PromoverFuncionario(Colaborador colaborador, String novoCargo, Double novoSalario) {

        if (colaborador.getSalario() < novoSalario) {
            System.out.println("Colaborador Promovido");
            colaborador.setSalario(novoSalario);
            colaborador.setCargo(novoCargo);
            totalPromovidos++;
        } else {
            System.out.println("Operação invalida");
        }

    }

    public Integer getTotalPromovidos() {
        return totalPromovidos;
    }

    public Integer getTotalSalariosReajustados() {
        return totalSalariosReajustados;
    }

}
