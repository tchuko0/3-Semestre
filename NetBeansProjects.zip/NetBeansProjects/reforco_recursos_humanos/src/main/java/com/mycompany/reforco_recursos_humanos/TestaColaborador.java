/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.reforco_recursos_humanos;

/**
 *
 * @author dener.souza
 */
public class TestaColaborador {

    public static void main(String[] args) {

        Colaborador cola1 = new Colaborador("Dener", "DBA");
        Colaborador cola2 = new Colaborador("Diego", "Dev");
        RecursosHumanos rh = new RecursosHumanos();

//      Adicionado o salario para cada colaborador e mostrando  
        cola1.setSalario(7000.0);
        cola2.setSalario(6000.0);
        System.out.println(cola1);
        System.out.println(cola2);

//      Adicionado o reajuste de 5% no salario dos colaboradores e mostrando  
        rh.reajustarSalario(cola2, 5.0);
        rh.reajustarSalario(cola1, 5.0);
        System.out.println(cola2);
        System.out.println(cola1);

//      Promovendo um colaborador com salario maior e outro com menor e mostrando  
        rh.PromoverFuncionario(cola2, "Gestor", 10000.0);
        rh.PromoverFuncionario(cola1, "PO", 100.0);
        System.out.println(cola2);
        System.out.println(cola1);

//      Mostrando a quantidade de salarios reajustados e qtd de promovidos  
        System.out.println(rh.getTotalPromovidos());
        System.out.println(rh.getTotalSalariosReajustados());
    }

}
