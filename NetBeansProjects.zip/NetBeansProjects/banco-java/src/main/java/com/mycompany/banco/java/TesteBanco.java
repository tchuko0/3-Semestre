/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banco.java;

import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author dener.souza
 */
public class TesteBanco {
    
    public static void main(String[] args) {
//         Esse objeto guarda as configurações fo banco de dados
        Connetion config = new Connetion();
        
        JdbcTemplate template = new JdbcTemplate(config.getDataSource());

//      Excluindo se a tabela já exixtir
       template.execute("DROP TABLE IF EXISTS pokemon");

//      Criando tabela  
        String criacaoTabelaPokemon = "CREATE TABLE pokemon("
                                     + "id INT PRIMARY KEY AUTO_INCREMENT,"
                                     + "nome VARCHAR(45),"
                                     + "tipo VARCHAR(45))";

//      Sempre depois de realizar um comando, chamar a variavel dentro do template.execulte  
        template.execute(criacaoTabelaPokemon);
        
//        Inserindo registros (sempre criar antes do select) É COM UPDATE !!!!

        String inserirScript = "INSERT INTO pokemon VALUES(null,?,?)";
        template.update(inserirScript,"Pokemon 01","agua");
        template.update(inserirScript,"Pokemon 02","fogo");
  
        List<Pokemon> listaPokemon1 = template.query("select * from pokemon",new BeanPropertyRowMapper<>(Pokemon.class));
        
        for (Pokemon pokemon : listaPokemon1) {
            System.out.println(pokemon);
        }
           
            
        }
        

        
    }
    


//C:\Users\dener.souza\OneDrive - Linx SA\Documentos\NetBeansProjects\banco-java
