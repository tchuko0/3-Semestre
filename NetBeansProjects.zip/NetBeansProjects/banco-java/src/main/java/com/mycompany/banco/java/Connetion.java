/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banco.java;

import javax.swing.border.EtchedBorder;
import org.apache.commons.dbcp2.BasicDataSource;

/**
 *
 * @author dener.souza
 */
public class Connetion {

    private BasicDataSource dataSource;

    public Connetion() {
        dataSource = new BasicDataSource();
        dataSource​.setDriverClassName("org.h2.Driver");
        dataSource​.setUrl("jdbc:h2:file:./meu_banco");
        dataSource​.setUsername("sa");
        dataSource​.setPassword("");
    }

    public BasicDataSource getDataSource() {
        return dataSource;
        
       
    }

    
}
