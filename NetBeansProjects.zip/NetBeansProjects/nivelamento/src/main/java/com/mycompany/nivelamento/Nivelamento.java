
package com.mycompany.nivelamento;

public class Nivelamento  {
    
    // Exemplo de comentario 
    
    //outro exemplo de comentario
    
    /* 
    
    */
    
    public static void main(String[] args) {
         /*
         O comando para exibição no console é o System.out.println e pula linha 
         
         O comando System.out.print exibe no console mais não pula linha 
        
         \t da um espaço no texto
        
        \n força a quebra de linha 
         */
         System.out.println("Hello World");
         System.out.print("Hello Dener");
         
    }
}
