package com.mycompany.nivelamento;

public class Tipos {

    public static void main(String[] args) {
        // ex de variavel do ripo texto (String)
        String nome = "Tchuko0";
        String nomeFaculade = "Dener Souza";

        // ex de variavel do ripo inteiro (integer) 
        Integer idedeDener = 24;
        Integer idadeRobson = 52;

        // ex de variavel do ripo real (Double) 
        Double alturaDener = 1.70;
        Double alturaRobson = 1.83;

        // ex de variavel do ripo Sim ou não (Boolean) 
        Boolean ligado = false;
        Boolean passouDeAno = true;

        // ex de variavel vazia(vazia) 
        String frase;
        Integer numero;
        Double numReal;
        Boolean SimNao;

        frase = "Primeira aula de JAVA";

    }
}
