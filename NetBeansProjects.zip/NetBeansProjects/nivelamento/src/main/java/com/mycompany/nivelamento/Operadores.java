
package com.mycompany.nivelamento;

public class Operadores {
    public static void main(String[] args) {
        
        Integer numero1 = 2;
        Integer numero2 = 1;
        
        Integer resultado = numero1 + numero2;
        
        System.out.println(resultado);
    }
    
}
