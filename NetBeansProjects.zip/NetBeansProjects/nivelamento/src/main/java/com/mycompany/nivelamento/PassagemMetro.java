
package com.mycompany.nivelamento;




public class PassagemMetro {
    public static void main(String[] args) {
        
       
        Double saldo = (250.5/4.40);
        
        
//        Scanner leitorNumero = new Scanner(System.in);
        System.out.println("Você ainda pode usar o metro por " + saldo.intValue());
//        Double numeroDigitado = leitorNumero.nextDouble();
        
       
        
       
        
        
    }
}
