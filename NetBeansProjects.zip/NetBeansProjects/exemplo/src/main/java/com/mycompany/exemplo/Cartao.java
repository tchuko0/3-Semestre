/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplo;

/**
 *
 * @author dener.souza
 */
public class Cartao {
    
    private String nomeCartao;
    private Double limete;
    private Integer numero;
    private static final Double taxaJuros = 15.0;

    public Cartao(String nomeCartao, Double limete, Integer numero) {
        this.nomeCartao = nomeCartao;
        this.limete = limete;
        this.numero = numero;
   
    }

    public String getNomeCartao() {
        return nomeCartao;
    }

    public void setNomeCartao(String nomeCartao) {
        this.nomeCartao = nomeCartao;
    }

    public Double getLimete() {
        return limete;
    }

    public void setLimete(Double limete) {
        this.limete = limete;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public static Double getTaxaJuros() {
        return taxaJuros;
    }

//    public void setTaxaJuros(Double taxaJuros) {
//        this.taxaJuros = taxaJuros;
//    }

    @Override
    public String toString() {
        return "Cartao{" + "nomeCartao=" + nomeCartao + ", limete=" + limete + ", numero=" + numero + ", taxaJuros=" + taxaJuros + '}';
    }
    
    
}
