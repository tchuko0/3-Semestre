/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplo;

/**
 *
 * @author dener.souza
 */
public class Teste {
    
    public static void main(String[] args) {
        Cartao c01 = new Cartao("dener", 400.0, 123);
        Cartao c02 = new Cartao("diego", 44000.0, 456);
       
        System.out.println(c01);
        System.out.println(c02);
        
        System.out.println(Cartao.getTaxaJuros());
    }
    
}
