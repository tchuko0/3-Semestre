
package com.mycompany.primeiroprojeto;


public class ProjetoTeste {
    public static void main(String[] args) {
        System.out.println("Olá Mundo !");
    }
}
