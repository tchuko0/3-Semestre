/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.agregacao.faculdade;

/**
 *
 * @author dener.souza
 */
public class TestarFaculdade {

    public static void main(String[] args) {

        Aluno aluno1 = new Aluno("12345", "Dener", 1);
        Aluno aluno2 = new Aluno("67890", "Diego", 2);
        Aluno aluno3 = new Aluno("20304", "Douglas", 3);
        Aluno aluno4 = new Aluno("50607", "Danilo", 4);

        Faculdade facul = new Faculdade("Sptech");

//      Matriculando alunos
        facul.matricularAluno(aluno1);
        facul.matricularAluno(aluno2);
        facul.matricularAluno(aluno3);
        facul.matricularAluno(aluno4);

//      Desmatriculando alunos      
        facul.cancelarMatricula("20304");
        facul.cancelarMatricula("50607");

//      Exibindos alunos (Matriculados ou não)      
        facul.exibirAlunos();

//      Exibindo alunos por semestre
        facul.exibirAlunosPorSemestre(1);

//      Exibindo alunos desmatriculados        
        facul.exibirCancelados();

    }

}
