/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.agregacao.faculdade;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dener.souza
 */
public class Faculdade {

    private String nome;
    private List<Aluno> alunos;

    public Faculdade(String nome) {
        this.nome = nome;
        this.alunos = new ArrayList<>();
    }

    public void matricularAluno(Aluno al) {
        alunos.add(al);

    }

    public void cancelarMatricula(String ra) {
        for (Aluno al : alunos) {
            if (al.getRa().equals(ra)) {
                al.setAtivo(false);
            }
        }

//        for (int i = 0; i < alunos.size(); i++) {
//            if (alunos.get(i).getRa().equals(ra)) {
//                alunos.remove(i);
//            }
//        }
    }

    public void exibirAlunos() {
        for (Aluno al : alunos) {
            System.out.println(al);
        }

    }

    public void exibirAlunosPorSemestre(Integer semestre) {
        for (int i = 0; i < alunos.size(); i++) {
            if (alunos.get(i).getSemestre().equals(semestre)) {
                System.out.println(alunos.get(i));
            }
        }

    }

    public void exibirCancelados() {
        for (Aluno al : alunos) {
            if (al.getAtivo().equals(false)) {
                System.out.println(String.format("O Aluno %s foi desmatriculado", al.getNome()));
            }
        }

    }

    @Override
    public String toString() {
        return String.format("Nome: %s\n"
                + "Alunos: %s\n"
                + "---------------------\n",
                nome, alunos);
    }

}
