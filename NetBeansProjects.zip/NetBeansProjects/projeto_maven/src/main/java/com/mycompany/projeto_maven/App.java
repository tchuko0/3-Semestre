/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto_maven;

import com.github.britooo.looca.api.core.Looca;
import com.github.javafaker.Faker;
import java.util.Locale;

/**
 *
 * @author dener.souza
 */
public class App {
    
    
    public static void main(String[] args) {
        
        Faker faker = new Faker(new Locale("pt-BR"));
        
        System.out.println(faker.name().fullName());
        System.out.println(faker.name().fullName());
        System.out.println(faker.gameOfThrones().house());
        
        System.out.println("-".repeat(20));
        
        Looca looca = new Looca();
        System.out.println(looca.getSistema());
        
    }
}
