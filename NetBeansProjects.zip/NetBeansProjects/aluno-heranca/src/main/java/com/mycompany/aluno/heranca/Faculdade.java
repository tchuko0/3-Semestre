/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aluno.heranca;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dener.souza
 */
public class Faculdade {
    
    private String nome;
    private List<Aluno>Alunos;

    public Faculdade(String nome) {
        this.nome = nome;
        this.Alunos = new ArrayList<>();
    }
    
    public void matricularAluno(Aluno aluno){
        this.Alunos.add(aluno);
        
    }
    
    
    
}
