/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aluno.heranca;

/**
 *
 * @author dener.souza
 */
public class AlunoGraduacao extends Aluno{
   private Double notaContinuada;
   private Double notaIntegrada;

    public AlunoGraduacao(Double notaContinuada, Double notaIntegrada, String ra, String nome) {
        super(ra, nome);
        this.notaContinuada = notaContinuada;
        this.notaIntegrada = notaIntegrada;
        
        
    }

    public Double getNotaContinuada() {
        return notaContinuada;
    }

    public void setNotaContinuada(Double notaContinuada) {
        this.notaContinuada = notaContinuada;
    }

    public Double getNotaIntegrada() {
        return notaIntegrada;
    }

    public void setNotaIntegrada(Double notaIntegrada) {
        this.notaIntegrada = notaIntegrada;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return String.format("---\n"
                + "%s\n"
                + "nota continuada: %.2f \n"
                + "nota integrada: %.2f \n"
                ,super.toString(),this.notaContinuada,this.notaIntegrada);
    }
    
    
   
   
    
}
