/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aluno.heranca;

import java.util.ArrayList;
import java.util.List;
import javax.sound.sampled.AudioFileFormat;

/**
 *
 * @author dener.souza
 */
public class TesteAluno {   
    public static void main(String[] args) {
        
        Aluno a1 = new Aluno("1234", "dener");
        AlunoGraduacao a2 = new AlunoGraduacao(10.0,10.0, "1234", "dener");

        
        System.out.println("Aluno Graduação");
        System.out.println(a2);

        System.out.println("Aluno");
        System.out.println(a1);
        
        
        List<Aluno> alunos = new ArrayList<>();
        List<AlunoGraduacao> alunosGraduacao = new ArrayList<>();
        
        alunos.add(a1);
        alunos.add(a2);
        
        
        Faculdade faculdade = new Faculdade("sptech");
        
        faculdade.matricularAluno(a1);
        faculdade.matricularAluno(a2);
       
        if (a1 instanceof AlunoGraduacao ) {
            System.out.println("Verdadeiro");
        }
        System.out.println("Falso");
        
    }
    

}
