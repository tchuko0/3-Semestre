
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Projeto {

    static void calculo() {
        Scanner leitor = new Scanner(System.in);

        System.out.println("digite o nome do seu lutador");
        String nomeLutador = leitor.nextLine();

        int vitorias = 0, empates = 0, derrotas = 0;

        for (int i = 0; i < 40; i++) {
            Integer numeroSorteado = ThreadLocalRandom.current().nextInt(1, 4);

            switch (numeroSorteado) {
                case 1:
                    vitorias++;
                    break;
                case 2:
                    empates++;
                    break;
                case 3:
                    derrotas++;
                    break;
            }
        }

        Integer pontuacao = (vitorias * 3) + empates;
        Double resultado = (pontuacao / (40 * 3.0)) * 100;

        System.out.println(String.format("O lutador %s ganhou %d na carreira e perdeu %d no decorrer da carreira de %.2f",
                 nomeLutador, vitorias, derrotas, resultado));

    }

    static void condicionais(int selecao) {

        switch (selecao) {
            case 1:
                System.out.println("Shang Tsung é o maior vencedor do torneio Mortal Kombat ganhando 9 vezes seguidas");
                break;
            case 2:
                System.out.println("Liu kang foi o escolhido por Raiden para vencer Shang Tsung, E venceu");
                break;
            case 3:
                System.out.println("Kung Lao foi morto por Shao Kahn mesmo depois de ter vencido a luta \n"
                        + "covardemente enquanto comemorava");
                break;
            case 4:
                System.out.println("Em pesquisas realizadas por fãs Scorpion e Sub-Zero \n"
                        + "são os principais personagens para muitos");
                break;
            default:
                System.out.println("Numero invalido");
                break;
        }

    }

    static void historia(int personagem) {

        System.out.println("Mortal kombat é uma franquia de jogo de luta \n"
                + "criado em 1992, com a ideia de inovar o mundo dos games quando o assunto fosse jogo de luta. \n"
                + "No inicio a franquia impactou por sua violecia que era o diferencial dos de mais jogos do mesmo genero \n ");

        switch (personagem) {
            case 1:
                System.out.println("Hanzo Hasashi conhecido como Scorpion, teve sua familia assassinada por Sub-Zero \n "
                        + "e por isso voltou da morte em busca de vingaça");
                break;
            case 2:
                System.out.println("Sub-Zero é um posto ocupado pelo melhor ninja do Shiray ruy \n "
                        + "e por 100 anos esse posto foi oculpado por uma familia com sede de sangue, com isso o glã passou a ser odiado");
                break;
            case 3:
                System.out.println("Deus do trovão responsavel por proteger a terra do seu irmão Shao Kahn");
                break;
            case 4:
                System.out.println("Shang Tsung é um feiticeiro que busca dominar a terra ao lado de Shao Kahn \n"
                        + "foi o unico a vencer o torneio 9 vezes seguidas");
                break;
            default:
                System.out.println("Numero invalido");
                break;
        }

    }

    static void sortearLuta() {

    }

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        Integer RespostaUsuario = 0;

        System.out.println(String.format("OPÇÕES: \n 1- Lute no Mortal Kombat"
                + " \n 2- Observações da Mortal Kombat \n 3- Historia da Mortal Kombat \n"
                + " 4- Encerrar \n"));

        RespostaUsuario = leitor.nextInt();

        switch (RespostaUsuario) {
            case 1:
                calculo();
                break;
            case 2:
                System.out.println(String.format(" 1- Quem é o maior campeão do Mortal kombat \n"
                        + "2- Lutador escolhido por Raiden \n"
                        + "3- Quem foi morto por Shao Kahn enquanto comemorava \n"
                        + "4- Personagens mais queridos pelos fâs"));
                int selecao = leitor.nextInt();
                condicionais(selecao);

                break;
            case 3:
                System.out.println(String.format(" 1- Scorpion \n"
                        + "2- Sub-Zero \n"
                        + "3- Raiden \n"
                        + "4- Shang Tsung"));
                int personagem = leitor.nextInt();
                historia(personagem);
                break;
            case 4:
                System.out.println("Até Logo...");
                break;
            case 5:
                System.out.println("");
                break;
            default:
                System.out.println("Numero invalido");
                break;
        }

    }
}
