/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula3;

import java.util.Scanner;

public class Exercicio2 {
    
    static void salarioMinimo (double salarioMinimo){

        Double sm = (salarioMinimo) /1100;
        
        if (sm>20) {
            System.out.println("Voce pertence a classe A");
        } else if (sm>=10 && sm<=20 ) {
            System.out.println("Voce pertence a classe B");
        } else if (sm >=4 && sm<=10) {
            System.out.println("Voce pertence a classe C");
        } else if (sm>=2 && sm <=4) {
            System.out.println("Voce pertence a classe D");
        } else {
            System.out.println("Voce pertence a classe E");
        }
 
    }
    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner(System.in);
        
        Double classeSocial = leitor.nextDouble() ;
        System.out.println("Informe seu salario");
        salarioMinimo(classeSocial);
        
        
       
        
        
    }
    
    
    
   
    
}
