
package com.mycompany.aula3;

import java.util.Scanner;
import javax.script.ScriptEngine;
import jdk.jfr.Period;


public class Utilitaria {

Scanner leitor = new Scanner(System.in);
    
//    assinatura do metodo
    void exibirLinha(){
//        Corpo do metodo
        System.out.println("Dener Souza");
        System.out.println("-".repeat(20));

        
//        criação de objeto
}
 
    void soma(int a , int b){
        
        int s = a + b;
        System.out.println(s);
   
    }
  
    void nome(){
    String name = leitor.nextLine();
    System.out.println(String.format("%s", name));
    }
    
    void nomeAltura(){
    System.out.println("DIgite seu nome");    
    String nome = leitor.nextLine();
    System.out.println("DIgite sua altura");  
    Double altura = leitor.nextDouble();
    System.out.println(String.format("seu nome é %s, sua altura é %.2f", nome,altura));
    
    }
    
              
}


    

