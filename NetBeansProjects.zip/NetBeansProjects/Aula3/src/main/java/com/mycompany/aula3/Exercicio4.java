/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula3;

import java.util.Scanner;


public class Exercicio4 {
    
   static double calcularDesconto (double quantidade , double produto){
       
       
        double somaProdVal = produto * quantidade;
        double total = somaProdVal*0.10;
        return total;
        
        
        
    }
    
    static void exibirNotaFiscal (){
        
       
        
        Scanner valor = new Scanner(System.in);
        Scanner qtd = new Scanner(System.in);
        
        
        System.out.println("Informe a quantidade");
        Integer resQtd = qtd.nextInt();
        System.out.println(resQtd);
        
        System.out.println("Informe o valor do produto");
        Integer resValor = valor.nextInt();
        System.out.println(resValor);
            
        
        double tot = calcularDesconto();

        double sa = calcularDesconto(resQtd, resValor);
        System.out.println(String.format("%d  %d %.2f ",  resQtd, resValor, sa));
        
       
    }
   
  
    
    public static void main(String[] args) {
        
        exibirNotaFiscal();
        

    }
    
}
