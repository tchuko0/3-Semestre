
package com.mycompany.aula3;


public class App {
    
    public static void main(String[] args) {
    
    Utilitaria utils = new Utilitaria();
    
     utils.exibirLinha();
     utils.nome();
     utils.nomeAltura();
    
    }
    
}
