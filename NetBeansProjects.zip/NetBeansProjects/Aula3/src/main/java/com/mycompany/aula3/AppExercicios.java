
package com.mycompany.aula3;


public class AppExercicios {
    
    Double nota1,nota2;
    
}
