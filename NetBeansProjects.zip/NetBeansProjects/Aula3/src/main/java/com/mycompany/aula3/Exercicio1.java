/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula3;

public class Exercicio1 {
    
   static void soma (int a , int b){
        
        int s = a+b;
        System.out.println(String.format("O resultado da soma é %d: ", s));
    
    }
   
   static int soma2 (int x, int z){
       int sm = x+z;
       return sm;
      
   }
   
   static void media(double n1, double n2){
       
       double cal = n1 + n2;
       System.out.println(String.format("media %.2f", cal));
   }
    
    public static void main(String[] args) {
        soma(1, 2);
        
        int sm = soma2(2,2);
        System.out.println(sm);
        
        media (0.4,0.6);
       
    }
    
}
