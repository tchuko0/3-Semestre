/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula3;

import java.util.Scanner;


public class Exercicio5 {
    
    
    
    static void imc (){
        
        Scanner altura = new  Scanner(System.in);
        Scanner peso = new  Scanner(System.in);
        Scanner sexo = new  Scanner(System.in);

        System.out.println("Informe seu sexo");
        String S = sexo.nextLine();
        System.out.println("Digite sua altura");
        Double alt = altura.nextDouble();
        System.out.println("Digite seu peso");
        Double kg = peso.nextDouble();
        System.out.println(String.format("%s, %.2f, %.2f", S,alt,kg));
        
        double resultado = kg/(alt * alt);
        System.out.println(resultado);

    }
       
    public static void main(String[] args) {

        
        
        imc();
        
 
    }
    
    
    
}
