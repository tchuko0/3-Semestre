/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.reforco_pokemon;

/**
 *
 * @author dener.souza
 */
public class Pokemon {
    
    private String nome;
    private String tipo;
    private Double forca;
    private Integer doce;

    public Pokemon(String nome, String tipo, Double forca) {
        this.nome = nome;
        this.tipo = tipo;
        this.forca = forca;
        this.doce = 0;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Double getForca() {
        return forca;
    }

    public void setForca(Double forca) {
        this.forca = forca;
    }

    public Integer getDoce() {
        return doce;
    }

    public void setDoce(Integer doce) {
        this.doce = doce;
    }


    @Override
    public String toString() {
        return String.format("Nome: %s\n"
                + "Tipo: %s\n"
                + "Força: %.2f\n"
                + "Doce: %d\n", 
                nome,
                tipo,
                forca,
                doce);
    }
    
    

    
    
    
}
