/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.reforco_pokemon;

/**
 *
 * @author dener.souza
 */
public class TestarPokemon {

    public static void main(String[] args) {
        Pokemon poke1 = new Pokemon("Dener", "Agua", 400.0);
        Pokemon poke2 = new Pokemon("Diego", "fogo", 5.0);
        TreinadorPokemon treino = new TreinadorPokemon();

        treino.treinarPokemon(poke1);
        treino.treinarPokemon(poke1);
        treino.treinarPokemon(poke1);
        treino.treinarPokemon(poke1);
        treino.treinarPokemon(poke1);


        treino.evoluirPokemon(poke1, "aaaa");

        System.out.println(poke1);

        poke1.setDoce(300);

        treino.evoluirPokemon(poke1, "Tchuko0");

        System.out.println(poke1);
        
        System.out.println("-".repeat(50));
        
        treino.treinarPokemon(poke2);
        treino.treinarPokemon(poke2);
        treino.treinarPokemon(poke2);
        treino.treinarPokemon(poke2);
        treino.treinarPokemon(poke2);

        treino.evoluirPokemon(poke2, "tchu");

        System.out.println(poke2);

        poke2.setDoce(20);

        treino.evoluirPokemon(poke2, "Evolução Diego");

        System.out.println(poke2);
        

        
    }

}
