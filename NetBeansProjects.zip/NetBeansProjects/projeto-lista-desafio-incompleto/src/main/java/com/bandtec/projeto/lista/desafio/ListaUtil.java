package com.bandtec.projeto.lista.desafio;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListaUtil {

    private List<Integer> inteiros;

    public ListaUtil() {
        this.inteiros = new ArrayList<>();
    }

    public void add(Integer valor) {
        if (valor != null) {
            inteiros.add(valor);
        }
    }

    public void remove(Integer valor) {
        inteiros.remove(valor);
    }

    public Integer count() {
        return inteiros.size();

    }

    public Integer countPares() {
        Integer qtd = 0;
        for (Integer inter : inteiros) {
            if (inter % 2 == 0) {
                qtd++;

            }
        }
        return qtd;

    }

    public Integer countImpares() {
        Integer qtd = 0;
        for (Integer inter : inteiros) {
            if (inter % 2 == 1) {
                qtd++;
            }
        }

        return qtd;
    }

    public Integer somar() {

        Integer conta = 0;

        for (Integer inter : inteiros) {
            conta += inter;
        }

        return conta;
    }

    public Integer getMaior() {

        if (inteiros.isEmpty()) {
            return 0;
        }

        Integer maior = Integer.MIN_VALUE;

        for (Integer inter : inteiros) {
            if (inter > maior) {
                maior = inter;
            }
        }

        return maior;

    }

    public Integer getMenor() {
        if (inteiros.isEmpty()) {
            return 0;
        }

        Integer menor = Integer.MAX_VALUE;

        for (Integer inter : inteiros) {
            if (inter <= menor) {
                menor = inter;
            }
        }

        return menor;
    }

    //        [1,2,3,4,4,5]
    public Boolean hasDuplicidade() {

            
       for (Integer inter : inteiros) {
            int posicaoInicial = inteiros.indexOf(inter);
            int posicaoFinal = inteiros.lastIndexOf(inter);

            if (posicaoInicial != posicaoFinal) {
                return true;
            }
      }
       return false;
       
       
//       O CODIGO ABAIXO  FUNCIONA TAMBEM  
//        for (Integer i = 0; i < inteiros.size(); i++) {
//            for (Integer j = 0; j < inteiros.size(); j++) {
//                if (inteiros.get(i).equals(inteiros.get(j))) {
//                    if (!i.equals(j)) {
//                        return true;
//                    }
//                }
//            }
//        }
//        return false
//
//    }
    }
}