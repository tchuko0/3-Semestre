
package com.mycompany.cursoguanabara;

public class primeiroPrograma {
    public static void main(String[] args) {
        System.out.println("Ola mundo");
    }
    
}
