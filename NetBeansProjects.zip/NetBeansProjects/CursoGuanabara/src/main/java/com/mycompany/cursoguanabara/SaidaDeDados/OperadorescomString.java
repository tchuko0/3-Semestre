/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cursoguanabara.SaidaDeDados;

/**
 *
 * @author dener.souza
 */
public class OperadorescomString {
    public static void main(String[] args) {
        
    String nome1 = "Dener";
    String nome2 = "Dener";
    String nome3 = new String("Dener");
    String res = nome1.equals(nome3)?"igual":"Diferente";
    
//    para comparar se um objeto é igual ao conteudo do outro / para objeto ao inves de usar == tem que usar .equals
    
        System.out.println(res);
        
    }
    

    
    
   
}
