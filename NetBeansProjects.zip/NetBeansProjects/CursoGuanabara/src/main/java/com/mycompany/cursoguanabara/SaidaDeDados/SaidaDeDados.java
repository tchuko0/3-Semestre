/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cursoguanabara.SaidaDeDados;

import java.util.Scanner;

/**
 *
 * @author dener.souza
 */
public class SaidaDeDados {
    
    public static void main(String[] args) {
        Scanner entradaNumero = new Scanner (System.in);
        Scanner entrada = new Scanner (System.in);
        
        Integer n1 =3;
        Integer n2=4;
        Integer soma = (n1 + n2);
        
        
        
        System.out.println("Digite seu nome ");
        String nome = entrada.nextLine();
        
        System.out.println("Digite sua idade ");
        Integer idade = entradaNumero.nextInt();
        
        System.out.println("Digite sua nota ");
        Float nota = entradaNumero.nextFloat();
        
        System.out.println(String.format("Seu nome é %s, tem %d e tirou %.1f na materia ",
                nome,idade,nota));
        

        
        System.out.println("a soma dos numeros é" + soma);
    }
}
