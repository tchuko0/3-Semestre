/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cursoguanabara.SaidaDeDados;



/**
 *
 * @author dener.souza
 */
public class OuEE {
    public static void main(String[] args) {
        
            Integer x = 10;
            Integer y = 15;
            Integer z = 20;
            
        boolean resposta;
//        Exemplo de && e as duas tem que ser verdade para dar verdadeiro 
        resposta = (x<z && z>y)? true:false;
        System.out.println(resposta);
        
//        Exemplo de || ou para ser verdadeiro qualquer uma das duas tem que ser verdade ou as duas sejam 
        resposta = (x<z || z==y)? true:false;
        System.out.println(resposta);
      
//        Exmplo de ^ ou exclusivo uma ou outra tem que ser verdadeira para ser verdade, se as duas foram falsas ou verdadeiras da falso
        resposta = (x<z || z==y)? true:false;
        System.out.println(resposta);
        
       
    }

}
