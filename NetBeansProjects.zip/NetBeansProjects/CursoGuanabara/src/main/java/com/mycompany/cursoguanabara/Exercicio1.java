
package com.mycompany.cursoguanabara;

import java.util.Date;


public class Exercicio1 {
    public static void main(String[] args) {
        Date relogio = new Date();

        
        System.out.println("A hora do sistema é");
        System.out.println(relogio.toString());
  
        
        
    }
    
}
