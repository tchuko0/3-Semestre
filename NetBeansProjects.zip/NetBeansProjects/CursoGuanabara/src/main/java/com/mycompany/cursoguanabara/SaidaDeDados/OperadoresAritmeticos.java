/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cursoguanabara.SaidaDeDados;

/**
 *
 * @author dener.souza
 */
public class OperadoresAritmeticos {
    public static void main(String[] args) {
//        Integer n1 = 3;
//        Integer n2 = 5;
//        float media = (n1 + n2)/2;
//        
//        System.out.println(String.format("A media é igual a %.2f", media));
    Integer numero = 5;
    numero--;
        System.out.println(numero);
    }
}
