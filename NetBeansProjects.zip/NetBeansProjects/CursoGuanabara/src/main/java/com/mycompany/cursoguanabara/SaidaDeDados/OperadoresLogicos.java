/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cursoguanabara.SaidaDeDados;

import java.util.Scanner;

/**
 *
 * @author dener.souza
 */
public class OperadoresLogicos {
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner (System.in);
        
        System.out.println("Digite um numero: ");
        Integer n1 = leitor.nextInt();
        
        System.out.println("Digite outro numero: ");
        Integer n2 = leitor.nextInt();
        
//        operador ternario Exemplo =  Integer maior = n1 > n2 ? n1:n2;
//        operador ternario com operação Exemplo =  Integer maior = n1 > n2 ? n1+1:n2+2;
        
       Integer maior = n1 > n2 ? n1+1:n2+2;
        
        System.out.println(maior);
        
    }
    
    
}
