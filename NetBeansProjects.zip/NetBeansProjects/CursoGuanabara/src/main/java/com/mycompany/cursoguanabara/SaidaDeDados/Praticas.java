/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cursoguanabara.SaidaDeDados;

import java.util.Scanner;

/**
 *
 * @author dener.souza
 */
public class Praticas {
    public static void main(String[] args) {
        
       
        Scanner leitorNumeror = new Scanner(System.in);
        
        System.out.println("Digite um numero");
        Integer n1 = leitorNumeror.nextInt();
        
        System.out.println("Digite outro numero");
        Integer n2 = leitorNumeror.nextInt();
        
        if (n1>n2) {
            System.out.println("O primeiro numero é maior");
        } else if (n1<n2) {
            System.out.println("o segundo numero é maior que o primeiro ");
        } else{
            System.out.println("os numeros são iguais ");
        }
        System.out.println("a soma dos numeros é " + (n1+n2));
        
//        System.out.println(n1+n2);
//        
//        for (int i = 1; i <= 10; i++) {
//            
//            System.out.println(i);
//        }
        
    }
}
