/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.produtora;

/**
 *
 * @author dener.souza
 */
public class Teste {
    public static void main(String[] args) {
        
        Produtora prod = new Produtora("aaaa");
        Ator atr = new Ator("Dener", 58, 200.0);
        Ator atr1 = new Ator("Diego", 58, 200.0);
        Protagonista atrP = new Protagonista(60, 400.0, "Karen", 60, 200.0);
        
        // contratando desenvolvedores
        prod.contratar(atr);
        prod.contratar(atr1);
        prod.contratar(atrP);
        
        // nome existente
        System.out.println(prod.existsAlunoPorNome("danilo")); 
        
        // nome Inexistente
        System.out.println(prod.existsAlunoPorNome("kssss"));
        
        // qtd de desenvolvedores
        System.out.println(prod.getQuantidadeDesenvolvedores());
        
         // qtd de desenvolvedores mobile
        System.out.println(prod.getQuantidadeDesenvolvedoresMobile());
        
        // soma dos salarios
        System.out.println(prod.getTotalSalarios());
        
        
    }
    
}
