/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.produtora;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dener.souza
 */
public class Produtora {

    private String nome;
    private Integer vagas;
    private List<Ator> atores;

    public Produtora(String nome) {
        this.nome = nome;
        this.vagas = 0;
        this.atores = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getVagas() {
        return vagas;
    }

    public void setVagas(Integer vagas) {
        this.vagas = vagas;
    }

    public List<Ator> getAtores() {
        return atores;
    }

    public void setAtores(List<Ator> atores) {
        this.atores = atores;
    }

    public Boolean existsAlunoPorNome(String nome) {

        for (int i = 0; i < atores.size(); i++) {
            if (atores.get(i).getNome().equals(nome)) {
                return true;
            }
        }

        return false;

    }

    public void contratar(Ator ator) {
        if (vagas >= 0) {
            atores.add(ator);
        }

        System.out.println("Sem vagas disponíveis!");
    }

    public Integer getQuantidadeDesenvolvedores() {

        return atores.size();

    }

    public Integer getQuantidadeDesenvolvedoresMobile() {
        Integer atoresProtagonistas = 0;

        for (Integer i = 0; i < atores.size(); i++) {
            if (atores.get(i) instanceof Protagonista) {

                atoresProtagonistas++;

            }
        }

        return atoresProtagonistas;

    }

    public Double getTotalSalarios() {

        Double valTotal = 0.0;
        for (Ator atore : atores) {
            valTotal += atore.getSalario();
        }

        return valTotal;

    }

    public String buscarDesenvolvedorPorNome(String nome) {
        if (nome != null) {
            for (Ator atore : atores) {
                if (atore.getNome().equalsIgnoreCase(nome)) {

                }
            }
        }

        return null;

    }

}
