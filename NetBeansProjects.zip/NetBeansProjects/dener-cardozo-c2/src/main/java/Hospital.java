/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dener.souza
 */
public class Hospital {

    private String nome;
    private Integer quantidadeDePagamentos;
    private Integer quantidadeDeBonus;

    public Hospital(String nome) {
        this.nome = nome;
        this.quantidadeDePagamentos = 0;
        this.quantidadeDeBonus = 0;
    }

    public void realizarPagamento(Medico medico, Double valorPagamento) {
        if (medico.getAtivo()) {
            medico.setSalario(valorPagamento);
            quantidadeDePagamentos++;
            System.out.println("Realizando pagamento sem bonus");
            System.out.println(String.format("Valor do pagamento: R$%.2f ", valorPagamento));
            System.out.println(medico.toString());
        } else {
            System.out.println("Operação Invalida");
            System.out.println("-".repeat(50));
        }

    }

    public void realizarPagamento(Medico medico, Double valorPagamento, Integer valorBonus) {
        if (medico.getAtivo()) {
            Double valorFinal = valorPagamento + (valorPagamento * valorBonus / 100);
            medico.setSalario(valorFinal);

            quantidadeDePagamentos++;
            quantidadeDeBonus++;

            System.out.println("Realizado pagamento com Bonus");
            System.out.println(String.format("Valor do pagamento: R$%.2f", valorPagamento));
            System.out.println(String.format("Bonus: R$%d -> R$%.2f", valorBonus, valorFinal));
            System.out.println(medico.toString());
        } else {
            System.out.println("Operação Invalida");
            System.out.println("-".repeat(50));
        }

    }

    public void desligarMedico(Medico medico) {
        medico.setAtivo(false);
        System.out.println(String.format("O medico(a) %s foi desligado", medico.getNome()));
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getQuantidadeDePagamentos() {
        return quantidadeDePagamentos;
    }

    public void setQuantidadeDePagamentos(Integer quantidadeDePagamentos) {
        this.quantidadeDePagamentos = quantidadeDePagamentos;
    }

    public Integer getQuantidadeDeBonus() {
        return quantidadeDeBonus;
    }

    public void setQuantidadeDeBonus(Integer quantidadeDeBonus) {
        this.quantidadeDeBonus = quantidadeDeBonus;
    }

    @Override
    public String toString() {
        return String.format("Hospital: %s\n"
                + "Quantidade de pagamentos %d\n"
                + "Quantidade de bonus %d",
                nome,
                quantidadeDePagamentos,
                quantidadeDeBonus);
    }

}
