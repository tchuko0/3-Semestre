/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dener.souza
 */
public class TestarHospital {
    
    public static void main(String[] args) {
        Medico medico1 = new Medico(1, "Karen", "Biomedica");
        Medico medico2 = new Medico(2, "Viviane", "Cardiopata");
        Hospital hs = new Hospital("Santa Marcelina");

//      Exibindo os medicos  
        System.out.println(medico1);
        System.out.println("-".repeat(50));
        System.out.println(medico2);
        System.out.println("-".repeat(50));

//      Exibindo os medicos com o pagamento com bonus  
        hs.realizarPagamento(medico1, 2000.00);
        System.out.println("-".repeat(50));
        hs.realizarPagamento(medico2, 3000.00, 30);

//      Desligando o primeiro medico
        System.out.println("-".repeat(50));
        hs.desligarMedico(medico1);
        System.out.println("-".repeat(50));
        hs.realizarPagamento(medico1, 2000.00);
        
//      Exibindo os medicos  
        System.out.println(medico1);
        System.out.println("-".repeat(50));
        System.out.println(medico2);
        System.out.println("-".repeat(50));
        
//      Exibindo as infomações do Hospital
        System.out.println(hs);

    }

}
    

