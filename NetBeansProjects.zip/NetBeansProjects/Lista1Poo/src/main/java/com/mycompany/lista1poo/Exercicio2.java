/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lista1poo;

public class Exercicio2 {

    String tamanho;
    String enderecoRemetente;
    String enderecoDestinatario;
    Double distancia;
    Double valorEncomenda;
    Double valorFrete;
    Double valorTotal = 0.0;

    Double calcularFrete() {

        if (tamanho.equals("P")) {
            valorTotal = valorEncomenda + valorEncomenda * 0.01;
        } else if (tamanho.equals("M")) {
            valorTotal = valorEncomenda + valorEncomenda * 0.03;
        } else if (tamanho.equals("G")) {
            valorTotal = valorEncomenda + valorEncomenda * 0.05;
        } else if (!"P".equals(tamanho) || !"M".equals(tamanho) || !"G".equals(tamanho)) {
            System.out.println("Tamanho Invalido");
        }
        



        if (distancia <= 50) {
            valorFrete = 3.00;
        } else if (distancia >= 51 && distancia <= 200) {
            valorFrete = 5.00;
        } else if (distancia >= 201) {
            valorFrete = 7.00;
        }

        return valorTotal = valorTotal + valorFrete;

    }

    void emitirEtiqueta() {

        System.out.println(String.format("***** ETIQUETA PARA ENVIO *****\n"
                + "Endereço do Remetente : %s \n"
                + "Endereço do Destinatário : %s\n"
                + "Tamanho : %s \n"
                + "-----------------------------\n"
                + "Valor encomenda : R$%.2f \n"
                + "Valor Frete : R$ %.2f\n"
                + "-----------------------------\n"
                + "Valor Final : R$ %.2f ", enderecoRemetente, enderecoDestinatario, tamanho, valorEncomenda, valorFrete, valorTotal));
    }

}
