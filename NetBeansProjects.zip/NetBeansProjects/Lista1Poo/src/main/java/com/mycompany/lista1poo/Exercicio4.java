package com.mycompany.lista1poo;

/**
 *
 * @author dener.souza
 */
public class Exercicio4 {

    Double atualTemperatura;
    Double minimaTemperatura;
    Double maximaTemperatura;

    void aumentarTemp(Double aumenta) {

        if (aumenta > maximaTemperatura) {
            atualTemperatura = maximaTemperatura;
        } else {
            atualTemperatura = aumenta;
        }
    }

    void diminuirTemp(Double diminuir) {

        if (diminuir < minimaTemperatura) {
            atualTemperatura = minimaTemperatura;
        } else {
            atualTemperatura = diminuir;
        }
    }

    void exibirFahreinheit() {

        System.out.println(String.format("Temperatura em Fahreinheit %.1f", atualTemperatura * 1.8 + 32));

    }

}
