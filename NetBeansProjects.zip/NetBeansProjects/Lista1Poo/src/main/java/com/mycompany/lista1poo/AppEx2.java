/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lista1poo;

import java.util.Scanner;

public class AppEx2 {

    public static void main(String[] args) {

//        Scanner leitor = new Scanner(System.in);
        
        Exercicio2 compra1 = new Exercicio2();
        Exercicio2 compra2 = new Exercicio2();
        Exercicio2 compra3 = new Exercicio2();

        compra1.distancia = 12.0;
        compra1.enderecoDestinatario = "Rua Antonio Lucas 169";
        compra1.enderecoRemetente = "Rua dos texteis, 781";
        compra1.tamanho = "P";
        compra1.valorEncomenda = 50.00;

        compra2.distancia = 12.0;
        compra2.enderecoDestinatario = "Rua Antonio Lucas 169";
        compra2.enderecoRemetente = "Rua dos texteis, 781";
        compra2.tamanho = "M";
        compra2.valorEncomenda = 60.00;

        compra3.distancia = 12.0;
        compra3.enderecoDestinatario = "Rua antonio lucas, 169";
        compra3.enderecoRemetente = "Rua dos texteis, 781";
        compra3.tamanho = "G";
        compra3.valorEncomenda = 70.00;
        
//        exemplo de usar scanner no objeto
//        System.out.println("informe o endereco do destinatario");
//        compra3.enderecoDestinatario = leitor.nextLine();
// 
//        System.out.println("informe o tamanho");
//        compra3.tamanho = leitor.nextLine();

        compra1.calcularFrete();
        compra1.emitirEtiqueta();

        compra2.calcularFrete();
        compra2.emitirEtiqueta();

        compra3.calcularFrete();
        compra3.emitirEtiqueta();

    }

}
