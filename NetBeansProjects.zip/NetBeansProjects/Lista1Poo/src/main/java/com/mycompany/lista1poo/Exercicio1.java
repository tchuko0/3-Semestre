package com.mycompany.lista1poo;

import java.util.Scanner;

public class Exercicio1 {

    String sabor;
    Double valor;
    Integer emEstoque = 100;

    Boolean comprarBolo(int qtdPedido) {

        if (qtdPedido > emEstoque || qtdPedido > emEstoque) {
            System.out.println("Seu pedido ultrapassou nosso limite diário para esse bolo.");
            return false;

        } else {
            emEstoque -= qtdPedido;
            return true;

        }

    }

    void relatorio(int qtdPedido) {

        double total = qtdPedido * valor;
        System.out.println(String.format("O bolo sabor %s, foi comprado %d vezes hoje, totalizando R$ %.2f", sabor, qtdPedido, total));
    }

}

