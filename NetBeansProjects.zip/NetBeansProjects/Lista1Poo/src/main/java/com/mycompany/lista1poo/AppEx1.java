package com.mycompany.lista1poo;

//import java.util.Scanner;

public class AppEx1 {

    public static void main(String[] args) {

//        Scanner leitos = new Scanner(System.in);
//        Scanner leitor = new Scanner(System.in);
//        Scanner leito = new Scanner(System.in);
        
        Exercicio1 bolo1 = new Exercicio1();
        Exercicio1 bolo2 = new Exercicio1();
        Exercicio1 bolo3 = new Exercicio1();
        
//        Integer qtdbolo;

       bolo1.sabor = "Chocolate";
        bolo1.valor = 30.00;

        bolo2.sabor = "Morango";
       bolo2.valor = 40.00;

       bolo3.sabor = "coco";
        bolo3.valor = 50.00;
        


//        System.out.println(String.format("escolha o sabor do bolo", bolo1.sabor));
//        bolo1.sabor = leitos.nextLine();
//
//        System.out.println(String.format("informe o valor do bolo", bolo1.valor ));
//        bolo1.valor = leitos.nextDouble();
//
//        System.out.println(String.format("escolha o sabor do bolo", bolo2.sabor));
//        bolo2.sabor = leitor.nextLine();
//
//        System.out.println(String.format("informe o valor do bolo", bolo2.valor ));
//        bolo2.valor = leitor.nextDouble();
//
//        System.out.println(String.format("escolha o sabor do bolo", bolo3.sabor));
//        bolo3.sabor = leito.nextLine();
//        
//        
//
//        System.out.println(String.format("informe o valor do bolo", bolo3.valor ));
//        bolo3.valor = leitos.nextDouble();
//        
//        
//        Double total = bolo1.valor + bolo2.valor + bolo3.valor;
//       
//        
//        System.out.println(String.format("voce gastou no total %.2f Reais",total));
        

        bolo1.relatorio(2);
        bolo1.relatorio(4);
        bolo1.relatorio(2);

        bolo2.relatorio(6);
        bolo2.relatorio(4);
        bolo2.relatorio(2);

        bolo3.relatorio(6);
        bolo3.relatorio(4);
        bolo3.relatorio(2);

    }

}
