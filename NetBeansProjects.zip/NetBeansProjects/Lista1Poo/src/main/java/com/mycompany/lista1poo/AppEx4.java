package com.mycompany.lista1poo;

/**
 *
 * @author dener.souza
 */
public class AppEx4 {

    public static void main(String[] args) {

        Exercicio4 temperatura1 = new Exercicio4();

        temperatura1.atualTemperatura = (26.6);
        temperatura1.minimaTemperatura = (18.5);
        temperatura1.maximaTemperatura = (33.5);

        System.out.println(String.format("Temperatural Atual %.1f", temperatura1.atualTemperatura));

        temperatura1.aumentarTemp(29.0);
        System.out.println(String.format("Temperatural Atual %.1f", temperatura1.atualTemperatura));

        temperatura1.aumentarTemp(37.0);
        System.out.println(String.format("Temperatural Atual %.1f", temperatura1.atualTemperatura));

        temperatura1.aumentarTemp(27.0);
        System.out.println(String.format("Temperatural Atual %.1f", temperatura1.atualTemperatura));

        temperatura1.diminuirTemp(23.1);
        System.out.println(String.format("Temperatural Atual %.1f", temperatura1.atualTemperatura));

        temperatura1.diminuirTemp(22.1);
        System.out.println(String.format("Temperatural Atual %.1f", temperatura1.atualTemperatura));

        temperatura1.diminuirTemp(21.1);
        System.out.println(String.format("Temperatural Atual %.1f", temperatura1.atualTemperatura));

        temperatura1.exibirFahreinheit();
    }
}
