/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lista1poo;

public class AppEx3 {

    public static void main(String[] args) {

        Exercicio3 funcionario1 = new Exercicio3();
        Exercicio3 funcionario2 = new Exercicio3();

        funcionario1.nome = "João";
        funcionario1.cargo = "analista de sistemas";
        funcionario1.salario = 5.400;
        funcionario1.empregado(15.00);

        funcionario2.nome = "Dener";
        funcionario2.cargo = "DBA";
        funcionario2.salario = 7.000;
        funcionario2.empregado(10.00);

        System.out.println(String.format("%s, salario inicial de %.3f e o cargo %s",
                 funcionario1.nome, funcionario1.salario, funcionario1.cargo));

        System.out.println(String.format("%s, salario inicial de %.3f e o cargo %s",
                 funcionario2.nome, funcionario2.salario, funcionario2.cargo));

    }

}
