/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultoria;

/**
 *
 * @author dener.souza
 */
public class DesenvolvedorMobile extends Desenvolvidor {

    private Integer qtdHorasTrabalhadasMobile;
    private Double valorHorasTrabalhasMobile;

    public DesenvolvedorMobile(Integer qtdHorasTrabalhadasMobile, Double valorHorasTrabalhasMobile, String nome, Integer qtdHorasTrabalhadas, Double valorHoraTrabalhada) {
        super(nome, qtdHorasTrabalhadas, valorHoraTrabalhada);
        this.qtdHorasTrabalhadasMobile = qtdHorasTrabalhadasMobile;
        this.valorHorasTrabalhasMobile = valorHorasTrabalhasMobile;
    }

    public Double getSalario() {

        return super.getSalario() + (qtdHorasTrabalhadasMobile * valorHorasTrabalhasMobile);

    }

    public Integer getQtdHorasTrabalhadasMobile() {
        return qtdHorasTrabalhadasMobile;
    }

    public void setQtdHorasTrabalhadasMobile(Integer qtdHorasTrabalhadasMobile) {
        this.qtdHorasTrabalhadasMobile = qtdHorasTrabalhadasMobile;
    }

    public Double getValorHorasTrabalhasMobile() {
        return valorHorasTrabalhasMobile;
    }

    public void setValorHorasTrabalhasMobile(Double valorHorasTrabalhasMobile) {
        this.valorHorasTrabalhasMobile = valorHorasTrabalhasMobile;
    }

    @Override
    public String toString() {
        return "DesenvolvedorMobile{" + "qtdHorasTrabalhadasMobile=" + qtdHorasTrabalhadasMobile + ", valorHorasTrabalhasMobile=" + valorHorasTrabalhasMobile + '}';
    }


    
}
