/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultoria;

/**
 *
 * @author dener.souza
 */
public class Teste {

    public static void main(String[] args) {
        Consultoria consu1 = new Consultoria("Linx");
        Desenvolvidor dev = new Desenvolvidor("Dener", 58, 200.0);
        Desenvolvidor dev1 = new Desenvolvidor("Diego", 58, 200.0);
        DesenvolvedorMobile devMob = new DesenvolvedorMobile(60, 300.0, "danilo", 70, 400.0);
        
        // contratando desenvolvedores
        consu1.contratar(dev);
        consu1.contratar(dev1);
        consu1.contratar(devMob);
        
        // nome existente
        System.out.println(consu1.existsAlunoPorNome("danilo")); 
        
        // nome Inexistente
        System.out.println(consu1.existsAlunoPorNome("karen"));
        
        // qtd de desenvolvedores
        System.out.println(consu1.getQuantidadeDesenvolvedores());
        
         // qtd de desenvolvedores mobile
        System.out.println(consu1.getQuantidadeDesenvolvedoresMobile());
        
        // soma dos salarios
        System.out.println(consu1.getTotalSalarios());
        
        
    }

}
