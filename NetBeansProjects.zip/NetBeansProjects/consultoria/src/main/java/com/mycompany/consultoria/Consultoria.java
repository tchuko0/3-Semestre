/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultoria;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dener.souza
 */
public class Consultoria {

    private String nome;
    private Integer vagas;
    private List<Desenvolvidor> desenvolvidores;

    public Consultoria(String nome) {
        this.nome = nome;
        this.vagas = 0;
        this.desenvolvidores = new ArrayList<>();
    }

    public Boolean existsAlunoPorNome(String nome) {

        for (int i = 0; i < desenvolvidores.size(); i++) {
            if (desenvolvidores.get(i).getNome().equals(nome)) {
                return true;
            }
        }

        return false;

    }

    public void contratar(Desenvolvidor desenvolvidor) {
        if (vagas >=0) {

            desenvolvidores.add(desenvolvidor);
        }
        System.out.println("Sem vagas disponíveis!");

    }

    public Integer getQuantidadeDesenvolvedores() {

        return desenvolvidores.size();

    }

    public Integer getQuantidadeDesenvolvedoresMobile() {
        Integer desenvolvedoresMobile = 0;

        for (Integer i = 0; i < desenvolvidores.size(); i++) {
            if (desenvolvidores.get(i) instanceof DesenvolvedorMobile) {

                desenvolvedoresMobile++;

            }
        }

        return desenvolvedoresMobile;

    }

    public Double getTotalSalarios() {

        Double valTotal = 0.0;
        for (Desenvolvidor desenvolvidore : desenvolvidores) {
            valTotal += desenvolvidore.getSalario();
        }

        return valTotal;

    }

    public String buscarDesenvolvedorPorNome(String nome) {
        if (nome != null) {
            for (Desenvolvidor desenvolvidore : desenvolvidores) {
                if (desenvolvidore.getNome().equalsIgnoreCase(nome)) {
                    return nome;
                }
            }
        }

        return null;

    }

}
