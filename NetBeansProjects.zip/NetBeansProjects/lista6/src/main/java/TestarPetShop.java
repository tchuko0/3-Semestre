/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dener.souza
 */
public class TestarPetShop {

    public static void main(String[] args) {

        Pet pat1 = new Pet("Amora", "maltes");
        Pet pat2 = new Pet("bolinha", "vira-lata");        
        PetShop pts = new PetShop("Seu pet");
        
        pts.darBanho(pat1, 100.0);
        pts.darBanho(pat1, 100.0, 10);
        pts.darBanho(pat2, 100.0);

        
        System.out.println("depois dos 2 banhos");

        System.out.println(pat1);
        System.out.println(pat2);
        
        System.out.println(pts.getFaturamento());
    }

}
