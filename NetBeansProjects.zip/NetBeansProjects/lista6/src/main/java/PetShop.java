/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dener.souza
 */
public class PetShop {

    private String nome;
    private Double faturamento;

    public PetShop(String nome) {
        this.nome = nome;
        this.faturamento = 0.0;
    }

    public void darBanho(Pet pat, Double valor) {
        faturamento = faturamento + valor;
        Double valorGastoNovo = pat.getValorGasto() + valor;
        pat.setValorGasto(valorGastoNovo);
        pat.banho();
    }

    public void darBanho(Pet pat, Double valor, Integer desconto) {
// quanto vai ter de desconto       
        Double valorDesconto = (desconto / 100.0) * valor;
// quanto vai pagar no final (valor - desconto)  
        Double valorFinalAPagar = valor - valorDesconto;
// Atualizado valor do faturamento
        faturamento = faturamento + valorFinalAPagar;
// pagando o que pet já gastou antes + valor do banho
        Double novoValorGastoDoPet = pat.getValorGasto() + valorFinalAPagar;
        pat.setValorGasto(novoValorGastoDoPet);
        pat.banho();

    }
// quanto é 32% de 150
//    32/100 * 150

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getFaturamento() {
        return faturamento;
    }

    public void setFaturamento(Double faturamento) {
        this.faturamento = faturamento;
    }

    @Override
    public String toString() {
        return "PetShop{" + "nome=" + nome + ", faturamento=" + faturamento + '}';
    }
    

}
