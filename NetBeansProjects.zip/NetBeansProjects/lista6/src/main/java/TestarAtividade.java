


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author dener.souza
 */
public class TestarAtividade {

    public static void main(String[] args) {

        Planejamento planejamento1 = new Planejamento("analise", "Barreira", 10);
        Atividade att = new Atividade();

        planejamento1.setDiasUsados(10);
        att.calcularTempo(planejamento1);

    }

}
