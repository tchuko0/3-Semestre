/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.util.Objects;

public class Atividade {

    public void terminarAtividade(Planejamento planejamento, Integer diasUtilizados) {
        if (planejamento.getDiasUsados() > diasUtilizados) {
            planejamento.setDiasUsados(diasUtilizados);
        }

    }

    public void calcularTempo(Planejamento planejamento) {
        Integer totalMais = planejamento.getDiasUsados() - planejamento.getDiasEstimados();
        if (planejamento.getDiasUsados() > planejamento.getDiasEstimados()) {
            System.out.println(String.format("Você estimou %d dias, mas a tarefa\n"
                    + "foi feita em %d dias (%d dias a mais que o estimado). Melhore a estimativa\n",
                    planejamento.getDiasEstimados(), planejamento.getDiasUsados(), totalMais));

        } else if (planejamento.getDiasUsados() < planejamento.getDiasEstimados()) {
            Integer totalMenos = planejamento.getDiasEstimados() - planejamento.getDiasUsados();
            System.out.println(String.format("Você"
                    + "estimou %d dias, e a tarefa foi feita em %d dias (%d dias a menos que o estimado).\n"
                    + "Parabéns!", planejamento.getDiasEstimados(), planejamento.getDiasUsados(), totalMenos));

        } else if (Objects.equals(planejamento.getDiasUsados(), planejamento.getDiasEstimados())) {
            System.out.println(String.format("Você\n"
                    + "estimou %d dias, e a tarefa foi feita em %d dias, atendendo a estimativa com precisão", planejamento.getDiasEstimados(), planejamento.getDiasUsados()));
        }

    }

}
