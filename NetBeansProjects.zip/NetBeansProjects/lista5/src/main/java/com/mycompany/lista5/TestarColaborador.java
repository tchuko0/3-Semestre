/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lista5;

public class TestarColaborador {

    public static void main(String[] args) {

        Colaborador colaborador1 = new Colaborador("Dener", "analista");
        Colaborador colaborador2 = new Colaborador("JC", "DEV", 2000.00);
        RecursosHumanos rh = new RecursosHumanos();

        System.out.println(colaborador1);
        System.out.println(colaborador2);

//  promovendo colaborador       
        rh.promoverColaborador(colaborador1, "DBA", 10000.00);
        System.out.println(colaborador1);

        rh.promoverColaborador(colaborador2, "Cientista de dados", 1000.00);
        System.out.println(colaborador2);
//  reajustando salario 

        rh.reajusteSalarial(50000.00, colaborador2);
        System.out.println(colaborador2);

        rh.reajusteSalarial(50000.00, colaborador1);
        System.out.println(colaborador1);

        System.out.println(rh.getTotalPromovidos());
        System.out.println(rh.getTotalSalariosReajustados());

    }

}

//3. Crie uma classe chamada TesteColaborador 
//
//Crie dois objetos do tipo Colaborador. 
//Crie um objeto do tipo RecursosHumanos. 
//Exiba as informações dos colaboradores. 
//Promova um colaborador com salário maior. 
//Promova um colaborador com salário menor. 
//Faça o reajuste de salário de um colaborador. 
//Exiba novamente as informações dos colaboradores. 
//Exiba o total de promovidos.
//Exiba o total de salários reajustados.
