/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lista5;

public class Pokemon {

    private String nomePokemon;
    private String tipo;
    private Double forca;
    private Integer doces = 0;

    public Pokemon(String nome, String tipo, Double forca) {
        this.nomePokemon = nome;
        this.tipo = tipo;
        this.forca = forca;
    }

    public String getNomePokemon() {
        return nomePokemon;
    }

    public void setNomePokemon(String nomePokemon) {
        this.nomePokemon = nomePokemon;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Double getForca() {
        return forca;
    }

    public void setForca(Double forca) {
        this.forca = forca;
    }

    public Integer getDoces() {
        return doces;
    }

    public void setDoces(Integer doces) {
        this.doces = doces;
    }

}

//➢ Métodos: 
//
//treinarPokemon: que recebe um pokemon e aumenta forca do pokemon em 10% além de aumentar a quantidade de doces em 10. O treinador também deverá ter seu nível aumentado em 2. 
//evoluirPokemon: que recebe o pokemon e o nome da evolução e realiza a seguinte operação:
//Caso a quantidade de doces do pokemon seja superior ou igual a 50, você deverá trocar o nome atual do pokemon pelo nome passado no método(argumento nomeEvolucao), diminuir em 50 a quantidade de doces do pokemon, aumentar a experiência do treinador em 10 e exibir a frase “Pokémon x evoluiu para -> y”, onde x é nome “antigo” e y é o nome atual(depois de evoluir).
// Caso a quantidade de doces seja inferior, apenas exiba a frase: “Não foi possível realizar operação”. 
