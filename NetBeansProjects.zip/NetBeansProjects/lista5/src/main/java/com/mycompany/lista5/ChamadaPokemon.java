/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lista5;

public class ChamadaPokemon {
    
    public static void main(String[] args) {
        
        Pokemon pokemon1 = new Pokemon("dener", "sla", 10.0);
        Pokemon pokemon2 = new Pokemon("jc", "sla q", 20.0);
        TreinadorPokemon treinar = new TreinadorPokemon();
        
        treinar.treinarPokemon(pokemon2);
        treinar.treinarPokemon(pokemon2);
        treinar.treinarPokemon(pokemon2);
        treinar.treinarPokemon(pokemon2);
        treinar.treinarPokemon(pokemon2);
        
        System.out.println(pokemon2.getForca());
        
        treinar.evoluirPokemon(pokemon2, "Jesus");
        System.out.println(pokemon2.getNomePokemon());
        
        treinar.treinarPokemon(pokemon1);
        treinar.treinarPokemon(pokemon1);
        
        System.out.println(pokemon1.getNomePokemon());
        
        treinar.evoluirPokemon(pokemon1, "Tchuko0");
        
        treinar.treinarPokemon(pokemon1);
        treinar.treinarPokemon(pokemon1);
        
        treinar.setNome("Diego");
        
        System.out.println(treinar.getNome());
        System.out.println(treinar.getNivel());
        
    }
    
}
