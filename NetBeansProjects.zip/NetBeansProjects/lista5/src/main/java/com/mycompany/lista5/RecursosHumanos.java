/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lista5;

public class RecursosHumanos {

    private Integer totalPromovidos;
    private Integer totalSalariosReajustados;

    
//    construtor não precisa iniciar sem argumentos é iniciado com 0
    public RecursosHumanos() {
        this.totalPromovidos = 0;
        this.totalSalariosReajustados = 0;
    }
    
    
    

    public Integer getTotalPromovidos() {
        return totalPromovidos;
    }

    public Integer getTotalSalariosReajustados() {
        return totalSalariosReajustados;
    }

    void reajusteSalarial(Double reajuste, Colaborador colaborador){
        totalSalariosReajustados++;
        colaborador.setSalario(reajuste);
        Double novoSalario = colaborador.getSalario() + reajuste;
        colaborador.setSalario(novoSalario);

    }

    void promoverColaborador(Colaborador colaborador, String novoCargo, Double novoSalario) {
        if (colaborador.getSalario() < novoSalario) {
            colaborador.setCargo(novoCargo);
            colaborador.setSalario(novoSalario);
            totalPromovidos++;
        } else {
            System.out.println("operação invalida");
        }

    }
}

//2. Crie uma classe chamada RecursosHumanos 
//
//Deve conter total de promovidos e total de salarios reajustados. 
//Deve conter um método reajustarSalario, que recebe um colaborador e o valor do reajuste(utilize Double). 
//Deve conter um método promoverColaborador, que recebe um colaborador, novo cargo e um novo salario. 
//Somente deverá ser realizada a promoção caso o novo salario informado seja maior que o salario atual do funcionario, caso não seja, exiba “operação inválida”.
