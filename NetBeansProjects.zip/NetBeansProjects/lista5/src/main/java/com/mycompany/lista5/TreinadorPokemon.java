/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lista5;

public class TreinadorPokemon {

    private String nome;
    private Integer nivel = 0;

    public TreinadorPokemon() {
    }

    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getNivel() {
        return nivel;
    }

    public void setNivel(Integer nivel) {
        this.nivel = nivel;
    }

    void treinarPokemon(Pokemon pokemon) {
        pokemon.setForca(pokemon.getForca() * 1.1);
        pokemon.setDoces(pokemon.getDoces() + 10);
        nivel += 2;

    }

  void evoluirPokemon(Pokemon pokemon, String nomeEvolucao) {
       
        if (pokemon.getDoces() >= 50) {
            System.out.println(String.format("Pokémon %s evoluiu para -> %s”", pokemon.getNomePokemon(), nomeEvolucao));
            pokemon.setDoces(pokemon.getDoces());
            pokemon.setNomePokemon(nomeEvolucao);
            
            nivel += 10;

        } else if (pokemon.getDoces() < 50) {
            System.out.println("Não foi possível realizar operação");
        }

    }

}

//evoluirPokemon: que recebe o pokemon e o nome da evolução e realiza a seguinte operação:
//Caso a quantidade de doces do pokemon seja superior ou igual a 50, você deverá trocar o nome atual do pokemon pelo nome passado no método(argumento nomeEvolucao), diminuir em 50 a quantidade de doces do pokemon, aumentar a experiência do treinador em 10 e exibir a frase “Pokémon x evoluiu para -> y”, onde x é nome “antigo” e y é o nome atual(depois de evoluir).
// Caso a quantidade de doces seja inferior, apenas exiba a frase: “Não foi possível realizar operação”. 
