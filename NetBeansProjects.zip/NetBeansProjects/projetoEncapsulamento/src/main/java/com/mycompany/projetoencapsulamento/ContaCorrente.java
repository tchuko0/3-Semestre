
package com.mycompany.projetoencapsulamento;


public class ContaCorrente {
    private String nomeTitula;
    private Double saldo;

    public ContaCorrente(String nomeTitula) {
        this.nomeTitula = nomeTitula;
        this.saldo = 0.0;
    }

    public String getNomeTitula() {
        return nomeTitula;
    }

    public void setNomeTitula(String nomeTitula) {
        this.nomeTitula = nomeTitula;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void depositar(Double valorDeposito){
        saldo += valorDeposito;
        
        
    }
    
    public void  sacar (Double valorSaque){
        saldo -= valorSaque;
        
        if (saldo < 0) {
            saldo =0.0;
            System.out.println("saque não permitido");
        } else {
             System.out.println("saque realizado");
             
        }
        
    }
    
}
