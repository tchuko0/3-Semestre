package com.mycompany.projetoencapsulamento;

public class aluno {

    private String nome;
    private String ra;
    private String curso;
    private Double nota1;
    private Double nota2;
    
    // gerando construtor

    public aluno(String nome, String ra, String curso) {
        this.nome = nome;
        this.ra = ra;
        this.curso = curso;
        this.nota1 = 0.0;
        this.nota2 = 0.0;
    }
    
    

//    Metodos sequem o padrao cameCase
    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return String.format("\n ra %s "
                + "\n nome %s "
                + "\n curso %s "
                + "\n nota1: %.1f"
                + "\n nota2 %.1f"
                + "\n media %.1f \n", ra, nome, curso, nota1, nota2, getMedia());
    }

    public void setNome(String nome) {
        this.nome = nome;

    }

    public String getRa() {
        return ra;
    }

    public void setRa(String ra) {
        this.ra = ra;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Double getNota1() {
        return nota1;
    }

    public void setNota1(Double nota1) {

        if (nota1 > 0 && nota1 <= 10) {
            this.nota1 = nota1;
        }
    }

    public Double getNota2() {
        return nota2;
    }

    public void setNota2(Double nota2) {

        if (nota2 > 0 && nota2 <= 10) {
            this.nota2 = nota2;
        }

    }

    public Double getMedia() {
        return (this.nota1 + this.nota2) / 2;
    }
    
    public  Boolean isAprovado(){
//        getMedia() > 6; maneira mais curta
    
        Double media = getMedia();
        if (media > 6) {
            return  true;
        } else {
            return  false;
        }
    }

}
