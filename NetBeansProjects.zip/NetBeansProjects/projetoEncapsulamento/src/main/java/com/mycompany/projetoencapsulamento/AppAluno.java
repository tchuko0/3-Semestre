/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetoencapsulamento;

public class AppAluno {

    public static void main(String[] args) {

        aluno aluno1 = new aluno("#Dener", "1234", "ads");

//        aluno1.setRa("#1234");
//        aluno1.setNome("Dener Cardozo");
//        aluno1.setCurso("analise e desenvolvimento de sistemas");
        aluno1.setNota1(10.0);
        aluno1.setNota2(8.0);

//        System.out.println(String.format("RA: %s", aluno1.getRa()));
//        System.out.println(String.format("Nome: %s", aluno1.getNome()));
//        System.out.println(String.format("curso: %s", aluno1.getCurso()));
//        System.out.println(String.format("nota 1: %.1f", aluno1.getNota1()));
//        System.out.println(String.format("nota 2: %.1f", aluno1.getNota2()));
//        System.out.println(String.format("media: %.1f", (aluno1.getNota1() + aluno1.getNota2()) / 2));

        System.out.println(aluno1);

    }

}
