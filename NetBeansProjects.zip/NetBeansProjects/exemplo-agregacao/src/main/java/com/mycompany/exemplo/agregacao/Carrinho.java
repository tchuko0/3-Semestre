/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplo.agregacao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dener.souza
 */
public class Carrinho {
    
    private String cliente;
    private List<Produto> produtos;
    
    public Carrinho(String cliente) {
        this.cliente = cliente;
        this.produtos = new ArrayList<>();
    }
    
    public Integer getQuantidade() {        
        return produtos.size();
    }
    
    public void adicionar(Produto prod) {
        produtos.add(prod);
        
    }
    
    public Boolean existsPorNome(String nome) {
        for (Produto prod : produtos) {
            if (prod.getNome().equals(nome)) {
                return true;
            }
        }
        return false;
    }
    
    public Integer getQuantidadePorCategoria(String nome) {
        Integer qtd = 0;
        for (Produto prod : produtos) {
            if (prod.getCategoria().equals(nome)) {
                qtd++;
            }
        }
        return qtd;
        
    }
    
    public void limpar() {
        produtos.clear();
    }
    
    public void removerPorNome(String nome) {
        for (int i = 0; i < produtos.size(); i++) {
            if (produtos.get(i).getNome().equals(nome)) {
                produtos.remove(i);
            }
        }
        
    }
    
    public Produto getPorNome(String nome) {
        for (Produto prod : produtos) {
            if (prod.getNome().equals(nome)) {
                return prod;
            }
        }
        return null;
    }
    
    public Double getTotalValor() {
        Double valTotal = 0.0;
        for (Produto prod : produtos) {
            valTotal += prod.getPreco();
        }
        
        return valTotal;
    }
    
    public String getCliente() {
        return cliente;
    }
    
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
    
// NÃO PRECISA GERAR GET E SET DA LISTA !!!
    
//    public List<Produto> getProduto() {
//        return produtos;
//    }
//    
//    public void setProduto(List<Produto> produto) {
//        this.produtos = produto;
//    }
////

    @Override
    public String toString() {
        return String.format("Nome do cliente: %s\n"
                + "Produto: %s\n"
                + "-----------------------------\n",
                 cliente, produtos);
    }
    
}
