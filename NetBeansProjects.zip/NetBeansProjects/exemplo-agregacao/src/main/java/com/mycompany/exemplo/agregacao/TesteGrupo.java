/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplo.agregacao;

/**
 *
 * @author dener.souza
 */
public class TesteGrupo {

    public static void main(String[] args) {

        Contato contado01 = new Contato("dener", "(11) 123");
        Contato contado02 = new Contato("diego", "(11) 456");
        Contato contado03 = new Contato("danilo", "(11) 789");
        Contato contado04 = new Contato("douglas", "(11) 111");

        Grupo grupo1 = new Grupo("amigos");
        Grupo grupo2 = new Grupo("trabalho");

//        adicionando no grupo 1
        grupo1.adicionar(contado01);
        grupo1.adicionar(contado02);
//        adicionando no grupo 2
        grupo2.adicionar(contado03);
        grupo2.adicionar(contado04);
        
        System.out.println("Grupo 1 e 2");
        System.out.println(grupo1);
        System.out.println(grupo2);
        
        System.out.println("Remover contato do grupo 1");
        
        grupo1.remover(contado02);
        
        System.out.println(grupo1);
    }

}
