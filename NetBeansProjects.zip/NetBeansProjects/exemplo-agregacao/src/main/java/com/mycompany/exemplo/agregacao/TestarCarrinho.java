/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplo.agregacao;

/**
 *
 * @author dener.souza
 */
public class TestarCarrinho {

    public static void main(String[] args) {

        Produto prod1 = new Produto("Banana", "Fruta");
        Produto prod2 = new Produto("Maça", "Fruta");
        Produto prod3 = new Produto("Banana", "Fruta");
        Produto prod4 = new Produto("TV", "EletroDomestico");
        Produto prod5 = new Produto("Video Game", "EletroDomestico");

        Carrinho car = new Carrinho("Dener");

        car.adicionar(prod1);
        car.adicionar(prod1);
        car.adicionar(prod2);
        car.adicionar(prod3);
        car.adicionar(prod4);
        car.adicionar(prod5);

        System.out.println(car);

        System.out.println(car.getQuantidade());

        System.out.println("---------------------");

        System.out.println(car.existsPorNome("TV"));

        System.out.println("-----------------------");

        System.out.println(car.getQuantidadePorCategoria("Fruta"));
//        
        car.removerPorNome("Banana");
        
        System.out.println(car);
//        
        System.out.println("-----------------------");

        System.out.println(car.existsPorNome("Banana"));
        
        System.out.println("-----------------------");

        prod1.setPreco(7.0);
        prod2.setPreco(6.0);

        System.out.println(car.getTotalValor());

    }

}
