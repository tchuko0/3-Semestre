
import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        // tipo ContaCorrente
        ContaCorrente conta1 = new ContaCorrente();
//        ContaCorrente conta2 = new ContaCorrente();

        conta1.nome = "Dener";
        conta1.saldo = 0.0;

//        conta2.nome = "Diego";
//        conta2.saldo = 100.0;
//        
        conta1.creditar(60.0);
        conta1.debitar(40.0);

        Scanner leitor = new Scanner(System.in);

//        System.out.println("Digite o saque");
//        Double valorSaque = leitor.nextDouble();
//        
//        conta1.sacar(valorSaque);
        System.out.println("Quanto depositar no bilhete");
        Double valorCreditado = leitor.nextDouble();

        conta1.creditar(valorCreditado);

        System.out.println(String.format("saldo atual: %.2f", conta1.saldo));

    }
}
