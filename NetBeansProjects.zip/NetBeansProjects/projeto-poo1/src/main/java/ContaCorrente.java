
import java.util.Scanner;


public class ContaCorrente {
    
    // declarando caracteristicas == atributos
    
    String nome;
    Double saldo;

    
//    // comportamentos == metodos
//    void depositar(double quantia){
//        
//        saldo += quantia;
//    }
//    
//    void sacar( double quantia){
//        
//        if (saldo < quantia ) {
//            System.out.println("saldo insuficiente");
//        } else {
//              saldo -= quantia;
//        }
//        
//      
//    }
    
    void debitar(double debitar){
        
        if (saldo > 2.20) {
            saldo -= 2.20;
            System.out.println("usou metro! saldo atual");
        } else {
            System.out.println("sem saldo");
        }
  
    }
    
    void creditar (double creditar){
        
        saldo+=creditar;
        System.out.println("carga efetuada");
        
    }
}
