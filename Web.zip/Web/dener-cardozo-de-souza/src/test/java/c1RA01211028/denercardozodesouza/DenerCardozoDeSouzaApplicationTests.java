package c1RA01211028.denercardozodesouza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DenerCardozoDeSouzaApplicationTests {

	@Test
	void contextLoads() {
	}

}
