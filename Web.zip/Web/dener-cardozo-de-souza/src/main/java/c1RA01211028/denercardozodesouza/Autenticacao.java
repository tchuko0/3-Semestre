package c1RA01211028.denercardozodesouza;

public class Autenticacao {


    private String usuario = "loginloko";
    private String senha = "senhaloka";
    private String nome = "Zé Buduia Loko";



    public Autenticacao(String usuario, String nome, boolean solto) {
        this.usuario = usuario;
        this.nome = nome;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

//    public String getSenha() {
//        return senha;
//    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }


}
