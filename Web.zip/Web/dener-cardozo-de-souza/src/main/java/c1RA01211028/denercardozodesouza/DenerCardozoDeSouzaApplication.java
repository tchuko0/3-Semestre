package c1RA01211028.denercardozodesouza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DenerCardozoDeSouzaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DenerCardozoDeSouzaApplication.class, args);
	}

}
