package c1RA01211028.denercardozodesouza;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class AutenticacaoController {

    private List<Autenticacao> provaList = new ArrayList<>();

    @PostMapping
    public Autenticacao post(@RequestBody Autenticacao autenticacao) {
        provaList.add(autenticacao);
        return autenticacao;

    }

    @GetMapping
    public List<Autenticacao> getGrifes() {

        return provaList;
    }

    @PostMapping("/autenticacao/{usuario}/{senha}")
    public String postAutenticar(@RequestBody Autenticacao autenticacao, @RequestBody String movaSenha, @RequestBody String novoLogin) {
       for (Autenticacao autenticacao1 :  provaList){
           if (autenticacao1.getUsuario().equals(novoLogin) && autenticacao1.)
       }
        provaList.add(autenticacao);
        return "autenticado";
    }


    @DeleteMapping("/autenticacao/{usuario}")
    public String deleteUsuario(@PathVariable int usuario){
        provaList.remove(usuario);
        return "Usuario excluido";
    }


}
