insert into fabricante_veiculos (nome) values
('GM'),('FIAT');



insert into cadastro_carro
(modelo, fabricante_id_fabricante, data_fabricacao, potencia_motor, ano)
values
('Esportivo',1,'2020-01-01',5.2, 2022),
('Cross', 2, '2020-01-01', 4.0, 2021),
('Vermelho', 1,'2020-01-01',4.5,2019),
('Preto',2,'2020-01-01', 4.7, 2020);
