package com.example.atContinuada1.controler;


import com.example.atContinuada1.dominio.CadastroCarro;
import com.example.atContinuada1.repositorio.CadastroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cadastros")
public class CadastroController {

    @Autowired
    private CadastroRepository repository;

    @PostMapping
    public ResponseEntity<CadastroCarro> post(
            @RequestBody CadastroCarro novoCarro) {
        repository.save(novoCarro);
        return ResponseEntity.status(201).body(novoCarro);
    }

//    @GetMapping
//    public ResponseEntity<List<CadastroCarro>> get() {
//        List<CadastroCarro> lista = repository.findAll();
//        return lista.isEmpty()
//                ? ResponseEntity.status(204).build()
//                : ResponseEntity.status(200).body(lista);
//    }

    @GetMapping("/{id}")
    public ResponseEntity<CadastroCarro> get(
            @PathVariable int id) {

        return ResponseEntity.of(repository.findById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.status(200).build();
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping()
    public ResponseEntity<List<CadastroCarro>> get(@RequestParam(required = false) String fabricante){
        List<CadastroCarro> carros = repository.findByFabricanteNomeContains(fabricante);

        if (fabricante == null){
            return getTodos();
        }else {
            if (carros.isEmpty()) {
                return ResponseEntity.status(204).build();
            }
            return ResponseEntity.status(200).body(carros);

        }


    }

    @GetMapping("/todos")
    public ResponseEntity<List<CadastroCarro>> getTodos(){
        List<CadastroCarro> carros = repository.findAll();
        if (carros.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(carros);
    }




    }


