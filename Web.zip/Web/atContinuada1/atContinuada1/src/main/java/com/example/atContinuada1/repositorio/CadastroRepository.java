package com.example.atContinuada1.repositorio;

import com.example.atContinuada1.dominio.CadastroCarro;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CadastroRepository extends JpaRepository<CadastroCarro, Integer> {

    List<CadastroCarro> findByFabricanteNomeContains(String nome);
}
