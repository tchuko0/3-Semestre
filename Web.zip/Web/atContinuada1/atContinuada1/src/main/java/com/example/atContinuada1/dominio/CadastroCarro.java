package com.example.atContinuada1.dominio;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.time.LocalDate;

@Entity
public class CadastroCarro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idCadastro;

    @NotBlank
    @Size(min = 2, max = 12)
 private String modelo;

    @NotBlank
    @Size(min = 2, max = 10)
    @ManyToOne
 private FabricanteVeiculos fabricante;

 private LocalDate dataFabricacao;
    @NotNull
    @DecimalMin("1950")
    @DecimalMax("2022")
 private Integer ano;
    @DecimalMin("0.2")
    @DecimalMax("7.0")
 private Double potenciaMotor;

    public Integer getIdCadastro() {
        return idCadastro;
    }

    public void setIdCadastro(Integer idCadastro) {
        this.idCadastro = idCadastro;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public FabricanteVeiculos getFabricante() {
        return fabricante;
    }

    public void setFabricante(FabricanteVeiculos fabricante) {
        this.fabricante = fabricante;
    }

    public LocalDate getDataFabricacao() {
        return dataFabricacao;
    }

    public void setDataFabricacao(LocalDate dataFabricacao) {
        this.dataFabricacao = dataFabricacao;
    }

    public Integer getAno() {
        return ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public Double getPotenciaMotor() {
        return potenciaMotor;
    }

    public void setPotenciaMotor(Double potenciaMotor) {
        this.potenciaMotor = potenciaMotor;
    }
}
