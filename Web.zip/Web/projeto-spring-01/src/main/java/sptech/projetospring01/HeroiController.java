package sptech.projetospring01;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/herois")// "/herois" passa a ser o inicio de todas URI
public class HeroiController {

    private List<String> herois = new ArrayList<>();

    @GetMapping
    public String home(){
        return "bem vindo a api de hereois "+" - cadastrados: " +this.herois.size();
    }

    @GetMapping("/cadastrar/{heroi}") // URI -> /herois/cadastrar
    public String cadastrar(@PathVariable String heroi){
        this.herois.add(heroi);
        return "Heroi cadastrado com sucesso";
    }


    @GetMapping("/recuperar/{heroi}")
    public String recuperar(@PathVariable int heroi){

            return herois.get(heroi);
    }

    @GetMapping("/atualizar/{posicao}/{novoNome}")
    public String atualiza(@PathVariable int posicao, @PathVariable String novoNome){
        if (posicao < 0 || posicao >= this.herois.size()){
            return "Heroi não encontrado";
        }

        this.herois.set(posicao, novoNome);
        return "Atualizar";
    }

    @GetMapping("/excluir/{posicao}")
    public String excluir(@PathVariable int posicao){
        if (posicao < 0 || posicao >= this.herois.size()){
            return "Heroi não encontrado #deuruim";
        }

        this.herois.remove(posicao);
        return "Excluido";
    }
}
