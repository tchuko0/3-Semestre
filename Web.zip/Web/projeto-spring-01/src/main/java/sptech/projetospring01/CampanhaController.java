package sptech.projetospring01;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/campanhas")
public class CampanhaController {

    private List<Campanha> campanhas = List.of(new Campanha("dener",10,10,10),
            new Campanha("Diego",10,9,8),
            new Campanha("danilo",10,20,4)

    );



    @GetMapping("/{posicao}")
    public Campanha campanha(@PathVariable int posicao){
        if (posicao < 0 || posicao >= this.campanhas.size()){
            return null;
        }

        return this.campanhas.get(posicao);
    }

    @GetMapping
    public List<Campanha>getCampanhas(){

        return campanhas;
    }
}
