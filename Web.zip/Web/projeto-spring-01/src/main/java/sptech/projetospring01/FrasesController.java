package sptech.projetospring01;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/*
@RestController é uma ANOTAÇÃO (Annotation)
Anotações são uma forma de META-PROGRAMAÇÃO

Esta anotação indica que a classe terá chamadas
da API REST do projeto
Ou seja é classe Controladora REST
 */
@RestController
public class FrasesController {

    /*
    A anotação @GetMapping é uma das formas de indicar
    que o método é uma CHAMADA da API REST
     */
    @GetMapping
    public String cumprimentar() {
        return "Bem vindos à minha API do S2";
    }

    /*
    Aqui dizemos que "/despedida" é a URI da chamada
     */
    @GetMapping("/despedida")
    public String despedir() {
        return "Tchau tchau, até mais!";
    }

    // Chamada localhost:8080/elogiar
    // ela devolve uma frase de elogio

    // Aqui a URI possui 2 PATH PARAMS (n1 e n2)
    // eles influenciam no resultado da chamada
    // eles foram atrelados aos parametros n1 e n2 respectivamente
    // por causa da anotação @PathVariable.
    // os parametros DEVEM possuir o mesmo nome que consta na URI
    @GetMapping("/somar/{n1}/{n2}")
    public Double somar(@PathVariable double n1, @PathVariable double n2) {
        return n1 + n2;
    }

    @GetMapping("/pode-votar/{idade}")
    public Boolean éMaior(@PathVariable int idade) {

        return idade >= 16;

    }



    @GetMapping("/resultado/{nota1}/{nota2}")
    public String result(@PathVariable Double nota1, @PathVariable Double nota2){
        if ((nota1 + nota2) > 6){
            return "Aprovado";
        }

        return "Reprovado";
    }
}
