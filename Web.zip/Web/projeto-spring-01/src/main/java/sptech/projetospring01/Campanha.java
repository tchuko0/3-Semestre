package sptech.projetospring01;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.UUID;

public class Campanha {
    /*
    * O Spring cria o JSON que representa um objeto da classe apartir do getter e setter
    *
    *
    * */

    @JsonIgnore // esta anotação impede que o campo vá para o JSON
    private UUID id = UUID.randomUUID();
    private String nome;
    private int empates;
    private int derrotas;
    private int vitorias;

    private boolean classificado = false;

    public Campanha(String nome, int empates, int derrotas, int vitorias) {
        this.nome = nome;
        this.empates = empates;
        this.derrotas = derrotas;
        this.vitorias = vitorias;
    }
        /*
     campo virtual
     campo calculado
     atributo virtual
     atributo calculado
        */



    public double getAproveitamento(){
        return(double) getPontos() / ((this.vitorias*3 + this.empates + this.derrotas)* 3) * 100;
    }

    public int getPontos(){
        return this.vitorias*3 + this.empates;
    }

    public String getNome() {
        return nome;
    }

    public int getEmpates() {
        return empates;
    }

    public int getDerrotas() {
        return derrotas;
    }

    public int getVitorias() {
        return vitorias;
    }

    public boolean isClassificado() {
        return classificado;
    }

    public UUID getId() {
        return id;
    }
}
