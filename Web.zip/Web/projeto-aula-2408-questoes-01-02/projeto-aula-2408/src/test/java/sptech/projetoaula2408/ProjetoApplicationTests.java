package sptech.projetoaula2408;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
