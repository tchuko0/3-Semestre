package sptech.projetoaula2408.questao1;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/grifes")
public class GrifeController {

    private List<Grife> grifes = new ArrayList<>();
    private List<Grife> populares = new ArrayList<>();


    @PostMapping
    public Grife post(@RequestBody Grife novaGrife) {
        grifes.add(novaGrife);
        return novaGrife;
    }

    @GetMapping
    public List<Grife> getGrifes() {

        return grifes;
    }

    @DeleteMapping("/{posicao}")
    public String delete(@PathVariable int posicao) {
        if (posicao >= 0 && posicao < grifes.size()) {
            grifes.remove(posicao);
            return "Grife excluída";
        }
        return "Não encontrada";
    }


    @PutMapping("/{posicao}")
    public Grife put(@PathVariable int posicao,
                        @RequestBody Grife grife) {
        if (posicao >= 0 && posicao < grifes.size()) {
            grifes.set(posicao, grife);
            return grife;
        }
        return null;
    }

    @GetMapping("/populares")
    public List<Grife> getPopulares(){
        for(Grife grife : grifes){
            if(grife.getValorAcaoBolsa() < 15){
                populares.add(grife);
            }
        }
        return populares;
    }

    @GetMapping("/{posicao}/cotas/{quantidade}/{chaveAcesso}")
    public Double getCota(@PathVariable int posicao,
                          @PathVariable int quantidade,
                          @PathVariable String chaveAcesso){

        if(posicao >= 0 && posicao < grifes.size()){

            if(grifes.get(posicao).chaveDeAcesso().equals(chaveAcesso)){

                return (double) grifes.get(posicao).getValorAcaoBolsa()* quantidade;

            }
        }

        return null;
    }


}
