package sptech.projetoaula2408.questao1;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Grife {
    private String nome;
    private int anoCriacao;
    private double valorAcaoBolsa;
    private String chaveAcesso;

    public Grife(String nome, int anoCriacao, double valorAcaoBolsa, String chaveAcesso) {
        this.nome = nome;
        this.anoCriacao = anoCriacao;
        this.valorAcaoBolsa = valorAcaoBolsa;
        this.chaveAcesso = chaveAcesso;
    }

    public String getNome() {

        return nome;
    }

    public int getAnoCriacao() {

        return anoCriacao;
    }

    public double getValorAcaoBolsa() {

        return valorAcaoBolsa;
    }

    public void setNome(String nome) {

        this.nome = nome;
    }

    public void setAnoCriacao(int anoCriacao) {

        this.anoCriacao = anoCriacao;
    }

    public void setValorAcaoBolsa(double valorAcaoBolsa) {

        this.valorAcaoBolsa = valorAcaoBolsa;
    }

//    public String getChaveAcesso() {
//        return chaveAcesso;
//    }
//
//    public void setChaveAcesso(String chaveAcesso) {
//        this.chaveAcesso = chaveAcesso;
//    }


    public void setAcaoBolsa(double acaoBolsa) {
        this. valorAcaoBolsa = valorAcaoBolsa;
    }

    public String chaveDeAcesso(){

        return chaveAcesso;
    }

    public void setChaveAcesso(String chaveAcesso) {

        this.chaveAcesso = chaveAcesso;
    }
}
