package sptech.projetoaula2408.questao2;

import org.springframework.web.bind.annotation.*;
import sptech.projetoaula2408.questao1.Grife;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/lutadores")
public class LutadorController {

    private List<Lutador> lutadores = new ArrayList<>();

    @PostMapping
    public Lutador post(@RequestBody Lutador novoLutador) {
        lutadores.add(novoLutador);
        return novoLutador;
    }

    @GetMapping
    public List<Lutador> getLutadores() {

        return lutadores;
    }

    @PatchMapping("/{posicaoBate}/golpe/{posicaoApanha}")
    public List<Lutador> golpear(@PathVariable int posicaoBate,
                                 @PathVariable int posicaoApanha) {
        if (posicaoBate < 0 || posicaoBate >= lutadores.size()
        || posicaoApanha < 0 || posicaoApanha >= lutadores.size()) {
            return null;
        }

        Lutador lutadorQueBate = lutadores.get(posicaoBate);
        Lutador lutadorQueApanha = lutadores.get(posicaoApanha);

        lutadorQueApanha.apanhar(lutadorQueBate);
        /*
        int forcaLiquidaGolpe = lutadorQueBate.getForcaGolpe() - lutadorQueApanha.getForcaDefesa();

        int novaVidaQueApanha = lutadorQueApanha.getVida() - forcaLiquidaGolpe;

        lutadorQueApanha.setVida(novaVidaQueApanha);
*/
        return List.of(lutadorQueBate, lutadorQueApanha);
    }
}
