package Projeto.exerciciopostget;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioPostGetApplicationTests {

	@Test
	void contextLoads() {
	}

}
