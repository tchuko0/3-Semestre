package Projeto.exerciciopostget;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/grifes")
public class ControllerGrifes {

    private List<Grifes> grifes = new ArrayList<>
            (List.of(new Grifes("Aramis", 1980, 15.5, "aaaaaaa")));

    @PostMapping
    public Grifes postGrifes(@RequestBody Grifes novaGrife) {
        grifes.add(novaGrife);
        return novaGrife;
    }

    @GetMapping // GET/pokemons
    public List<Grifes> getGrifes() {

        return grifes;
    }

    @PutMapping("/{posisao}")
    public String putGrife(@PathVariable int posisao, @RequestBody Grifes grife) {
        if (posisao < 0 || posisao >= this.grifes.size()) {
            return "Heroi não encontrado";
        }

        grifes.set(posisao, grife);
        return "Atualizar";

    }

    @DeleteMapping("/{posisao}")
    public String deleteGrife(@PathVariable int posisao) {
        if (posisao < 0 || posisao >= this.grifes.size()) {
            return "Não encontrada";
        }
        grifes.remove(posisao);
        return "grife excluida";
    }


}
