package sptech.projetojpadtoquery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoJpaDtoQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoJpaDtoQueryApplication.class, args);
	}

}
