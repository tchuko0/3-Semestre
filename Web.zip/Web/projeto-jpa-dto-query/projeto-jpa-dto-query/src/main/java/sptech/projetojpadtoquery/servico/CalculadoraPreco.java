package sptech.projetojpadtoquery.servico;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.net.PortUnreachableException;

public class CalculadoraPreco {

    private static final Double PRECO_KM = 12.0;

    public Double calcularPrecoDistancia(Double distanciaKm){
        if (distanciaKm == null || distanciaKm < 0.0){
           throw new  ResponseStatusException(
                   HttpStatus.BAD_REQUEST,
                   "Valor deve ser maior que 0.0"
           );
        }

        return distanciaKm * PRECO_KM;
    }


}
