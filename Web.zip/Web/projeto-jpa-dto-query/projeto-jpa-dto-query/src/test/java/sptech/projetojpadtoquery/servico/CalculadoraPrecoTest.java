package sptech.projetojpadtoquery.servico;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

import static org.junit.jupiter.api.Assertions.*;

class CalculadoraPrecoTest {

    CalculadoraPreco calculadoraPreco = new CalculadoraPreco();

    @Test
    @DisplayName("calcular Preço Quando Acionado Com Valor Deverá Retornar 24.0")
    void calcularPrecoQuandoAcionadoComValorDeveraRetornar24(){
       Double resultado = calculadoraPreco.calcularPrecoDistancia(2.0);

       assertEquals(24.0,resultado);
    }
    @Test
    @DisplayName("Quando acionado com valor negativo deverá lançar exceção")
    void calcularPrecoQuandoAcionadoComValorNegativoDeveraLancarExcecao(){
        assertThrows(ResponseStatusException.class, ()-> calculadoraPreco.calcularPrecoDistancia(-10.0));
    }

    @Test
    @DisplayName("Quando acionado com valor Nulo deverá lançar exceção")
    void calcularPrecoQuandoAcionadoComValorNuloDeveraLancarExcecao(){
      ResponseStatusException exception = assertThrows(ResponseStatusException.class, ()-> calculadoraPreco.calcularPrecoDistancia(null));
      assertEquals(400, exception.getRawStatusCode());
      assertEquals("Valor deve ser maior que 0.0",exception.getReason());
    }
}