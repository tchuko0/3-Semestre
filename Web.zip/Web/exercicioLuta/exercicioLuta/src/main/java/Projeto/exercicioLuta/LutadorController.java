package Projeto.exercicioLuta;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/lutadores")
public class LutadorController {

    private List<Lutador> lutadors = new ArrayList<>();


        @PostMapping
        public Lutador PostLutador(@RequestBody Lutador lutador){
            lutadors.add(lutador);
            return lutador;
        }

        @GetMapping
    public List<Lutador> getLutadors() {

            return lutadors;
    }

    @PatchMapping("/{posicaoBate}/golpe/{posisaoApanha}"){


    }
}
