package Projeto.exercicioLuta;

public class Lutador {

    private String nome;
    private Integer forcaGolpe;
    private Integer forcaDefesa;
    private Integer vida;

    public Lutador(String nome, Integer forcaGolpe, Integer forcaDefesa) {
        this.nome = nome;
        this.forcaGolpe = forcaGolpe;
        this.forcaDefesa = forcaDefesa;
        this.vida = 100;
    }

    public String getNome() {
        return nome;
    }

    public Integer getForcaGolpe() {
        return forcaGolpe;
    }

    public Integer getForcaDefesa() {
        return forcaDefesa;
    }

    public Integer getVida() {
        return vida;
    }
}
