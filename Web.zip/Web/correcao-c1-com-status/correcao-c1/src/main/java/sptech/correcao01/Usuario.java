package sptech.correcao01;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.validation.constraints.*;
import java.time.LocalDate;

public class Usuario {

    @NotBlank
    @Size(min = 3) // valida tamanho para o texto
    private String usuario;
    @NotBlank // so usa em string / obrigatorio para os demais tipos é o notNull
    @Size(min = 3, max = 16) // valida tamanho para o texto
    private String senha;

    @NotNull // valida se o campo esta presente e não é null
    @Min(0) // valida se o valor é no minimo 0
    // @DecimalMin("0.01") para validar casas decimais
    private Integer filhos;
    private String nome;

    @Past // Só seram datas passadas/ antes de hoje
    private LocalDate dataNasc; // formato: "aaaa/mm/dd"
    private boolean autenticado;

    public boolean autenticar(String usuario, String senha) {
        autenticado = usuario.equals(this.usuario) && senha.equals(this.senha);
        return autenticado;
    }

    public boolean isValido() {
        return usuario!=null && usuario.length() >= 3
                && senha!=null && senha.length() >= 3;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isAutenticado() {
        return autenticado;
    }

    public void setAutenticado(boolean autenticado) {
        this.autenticado = autenticado;
    }

    public Integer getFilhos() {
        return filhos;
    }

    public LocalDate getDataNasc() {
        return dataNasc;
    }
}
