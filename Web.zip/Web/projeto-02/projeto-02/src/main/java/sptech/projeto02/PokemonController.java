package sptech.projeto02;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/pokemons") // convenção é no plural
public class PokemonController {

    private List<Pokemon> pokemons = new ArrayList<>(List.of(new Pokemon("Pikachu","Eletrico",50.0, true),
            new Pokemon("Bubasaur","grama",20.0, false),
            new Pokemon("charmander","fogo",30.0, false)
            ));

    @GetMapping("/{posicao}") // localhost:8080/pokemons/{posicao}
    public Pokemon getPokemon(@PathVariable int posicao){

        return pokemons.get(posicao);
    }

    @DeleteMapping("/{posicao}") // DELETE/pokemons/{posicao}
    public String deletePokemon(@PathVariable int posicao){
        pokemons.remove(posicao);
        return "Pokemon excluido";
    }
    @GetMapping // GET/pokemons
    public List<Pokemon> getPokemons() {

        return pokemons;
    }

    @PostMapping("{posicao}") // POST/pokemons
    public Pokemon postPokemon(@RequestBody Pokemon novoPokemon){
        pokemons.add(novoPokemon);
        return novoPokemon;
    }

    @PutMapping("/{posicao}") // @PutMapping ATUALIZAR
    public Pokemon putPokemon(@PathVariable int posicao, @RequestBody Pokemon pokemon){

        pokemons.set(posicao, pokemon);
        return pokemon;

    }



}


