package sptech.projetojpa02.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;
import sptech.projetojpa02.dominio.AnimalEstimacao;

import java.util.List;

public interface AnimalEstimacaoRepository
                        extends JpaRepository<AnimalEstimacao, Long> {

    /*
    aqui usamos os Dynamic Finders
     */
    List<AnimalEstimacao>findByCodigo(Long codigo);

    List<AnimalEstimacao>findAll();
    List<AnimalEstimacao>findByCpfDono(String cpf);

    List<AnimalEstimacao>findByCpfDonoContains(String cpf);

    List<AnimalEstimacao>findByCpfDonoAndEmailDono(String cpf,String email);

    // select de boolea
    // List<AnimalEstimacao>findByCastradosTrue(); // todos castrados = true
    //  List<AnimalEstimacao>findByCastradosfalse(); // todos castrados = false


    Integer countByCastradoFalse();

    // Integer countByCastrado(boolean castrado);
    @Transactional
    @Modifying
    Integer deleteByCastradoFalse();

    boolean existsById(Long codigo);





   //  void deleteByCastradoFalse(); // nesse caso não retorna a quantidade excluido

}
