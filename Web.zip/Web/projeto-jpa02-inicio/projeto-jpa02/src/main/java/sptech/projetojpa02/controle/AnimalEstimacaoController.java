package sptech.projetojpa02.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.projetojpa02.dominio.AnimalEstimacao;
import sptech.projetojpa02.repositorio.AnimalEstimacaoRepository;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/pets")
public class AnimalEstimacaoController {

    @Autowired
    private AnimalEstimacaoRepository repository;

    @PostMapping
    public ResponseEntity postPet(
            @RequestBody @Valid AnimalEstimacao novoPet) {
        repository.save(novoPet);
        return ResponseEntity.status(201).build();
    }

    // @RequestParam indica um parametro de requisição, são valores apos a URI cujo primeiro iniciado por "?" e os demais por "&"

    //ex 1: /pets?cpf=45750262049
    //ex 2: /pets?cpf=46854944822&email=hhh@www.com
    //ex 3: /pets?cpf=46854944822&email=hhh@www.com&castrados=false

    // IMPORTANTE: a ordem deles na URL não importa! não precisa ser a mesma do cogigo

    // verifica se exite um cpf e um email como descrito na uri (localhost:8080/pets/busca-cpf?cpf=45750262049&email=aaaa@bbb)
    @GetMapping // pega pegar um valor especifico "CHAMADA FEITA NO REPOSITORY"
    public ResponseEntity getPets(@RequestParam(required = false) String cpf,
                                  @RequestParam(required = false) String email) {
        List<AnimalEstimacao> pets = repository.findByCpfDonoAndEmailDono(cpf, email);

        if (pets.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        return ResponseEntity.status(200).body(pets);
    }

    // verifica se existe o valor solicitado na uri (localhost:8080/pets/busca-cpf?cpf=45750262049)
    @GetMapping("/busca-cpf")
    public ResponseEntity getCpf(@RequestParam(required = false) String cpf) {
        List<AnimalEstimacao> pets = repository.findByCpfDono(cpf);
        if (pets.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(pets);
    }

    // verifica se algum dos insert contem o valor descrito no uri (localhost:8080/pets/contains?cpf=9)
    @GetMapping("/contains")
    public ResponseEntity getContains(@RequestParam(required = false) String cpf) {
        List<AnimalEstimacao> pets = repository.findByCpfDonoContains(cpf);

        return ResponseEntity.status(200).body(pets);
    }

    @GetMapping("/contagem-nao-castrados")
    public ResponseEntity<Integer> getPetsNaoCastrados() {
        Integer naoCastrados = repository.countByCastradoFalse();
        return ResponseEntity.status(200).body(naoCastrados);
    }

    @DeleteMapping("/nao-castrados")
    public ResponseEntity<Integer> deletePetsNaoCastrado() {
        Integer excluidos = repository.deleteByCastradoFalse();
        return ResponseEntity.status(200).body(excluidos);
    }

    @GetMapping("/tudo")
    public ResponseEntity getTudo() {
        List<AnimalEstimacao> pets = repository.findAll();
        if (pets.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(pets);
    }


    @PutMapping("/{codigo}")
    public ResponseEntity<AnimalEstimacao> putCodigo(
            @PathVariable Long codigo, @RequestBody AnimalEstimacao usuario) {
        List<AnimalEstimacao> pets = repository.findByCodigo(codigo);
        if (pets.isEmpty()) {
            return ResponseEntity.status(404).build();
        }
        usuario.setCodigo(codigo);
        repository.save(usuario); // faz um "update" pois o Codigo existe
        return ResponseEntity.status(200).body(usuario);

    }

    @DeleteMapping("/{codigo}")
    public ResponseEntity<Void> delete(
            @PathVariable Long codigo) {

        if (repository.existsById(codigo)) {
            repository.deleteById(codigo);

            return ResponseEntity.status(200).build();
        }
        return ResponseEntity.status(404).build();

    }
}


