public interface Tributavel {

//    metodo atributo
    public Double getValorTributo();

}
