public class Alimento extends Produto{

    private Integer quantVitaminas;

    public Alimento(Integer codigo, String descricao, Double preco, Integer quantVitaminas) {
        super(codigo, descricao, preco);
        this.quantVitaminas = quantVitaminas;
    }

    public Integer getQuantVitaminas() {
        return quantVitaminas;
    }

    public void setQuantVitaminas(Integer quantVitaminas) {
        this.quantVitaminas = quantVitaminas;
    }

    @Override
    public Double getValorTributo() {
        return getPreco() * 0.15;
    }

    @Override
    public String toString() {
        return "Alimento{" +
                "quantVitaminas=" + quantVitaminas +
                "} " + super.toString();
    }
}
