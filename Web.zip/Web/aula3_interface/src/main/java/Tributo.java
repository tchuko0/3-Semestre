import java.util.ArrayList;
import java.util.List;

public class Tributo {

    private List<Tributavel> tributoList;

    public Tributo() {
        this.tributoList = new ArrayList<>();
    }

    public void adcTributavel(Tributavel tributavel) {

        tributoList.add(tributavel);


    }

    public Double calcularTotalTributo() {

        Double total = 0.0;

        for (Tributavel t : tributoList) {
            total += t.getValorTributo();
        }

        return total;
    }

    public void exibirTodos() {

        for (Tributavel t : tributoList)
            System.out.println(t);
    }

}


