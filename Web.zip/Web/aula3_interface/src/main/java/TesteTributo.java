public class TesteTributo {

    public static void main(String[] args) {

        Alimento al = new Alimento(123,"aaaaa",200.0,10);

        Produto pr = new Perfume(123,"doce",200.0,"aaaa");

        Servico se = new Servico("aaa",400.0);

        Tributo tr = new Tributo();


        tr.adcTributavel(al);
        tr.adcTributavel(pr);
        tr.adcTributavel(se);

        System.out.println(tr.calcularTotalTributo());


        tr.exibirTodos();


    }
}
