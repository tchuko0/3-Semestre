## Como testar

### 1. Crie Bingos

**POST localhost:8080/bingos**

Ex de payload:
```json
{
  "premio": "PS 5"
}
```

### 2. Crie Cartelas

**POST localhost:8080/cartelas**

Ex de payload:
```json
{
  "dono": "Zé Buduia",
  "numero1": 25,
  "numero2": 14,
  "numero3": 23,
  "numero4": 9
}
```


### 3. Efetue "compras" de cartelas para os bingos

**POST localhost:8080/bingos/{idBingo}/inscricao-cartela/{idCartela}**


### 4. Efetue "sorteios" nos bingos

**POST localhost:8080/bingos/{idBingo}/sorteio**

Fazendo isso você verá na resposta do JSON os números que já foram sorteados. Veja abaixo:
```json
{
    "idBingo": 1,
    "premio": "PS 5",
    "numerosSorteados": "-11-12-24-1-10-4-17-23-7-5-7-26-2-14-12-20-25-21-23-5-10-9"
}
```
A cada sorteio, verifique se os números nas cartelas vão sendo marcados como sorteados, chamando o Endpoint...

**GET localhost:8080/bingos/{idBingo}/cartelas**

Fique fazendo quantos sorteios quiser.

Quando os números sorteados pararem de crescer então um ou mais Cartelas tiveram os 4 números sorteados.


### 5. Quando alguém tiver "batido", chame a consulta dos que bateram

**GET localhost:8080/bingos/{idBingo}/cartelas-batidas**

