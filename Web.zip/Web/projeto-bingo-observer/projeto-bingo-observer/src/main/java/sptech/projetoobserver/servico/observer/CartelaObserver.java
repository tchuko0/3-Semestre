package sptech.projetoobserver.servico.observer;

import sptech.projetoobserver.dominio.Cartela;
import sptech.projetoobserver.repositorio.CartelaRepository;

public class CartelaObserver {

    private CartelaRepository repository;
    private Integer idCartela;

    public CartelaObserver(Cartela cartela,
                           CartelaRepository repository) {
        this.idCartela = cartela.getIdCartela();
        this.repository = repository;
    }
    
    public Cartela getCartela() {
        return repository.findById(idCartela).get();
    }

    public void notificarSorteio(Integer numeroSorteado) {
        if (numeroSorteado.equals(getCartela().getNumero1())) {
            getCartela().setNumero1Sorteado(true);
        } else if (numeroSorteado.equals(getCartela().getNumero2())) {
            getCartela().setNumero2Sorteado(true);
        } else if (numeroSorteado.equals(getCartela().getNumero3())) {
            getCartela().setNumero3Sorteado(true);
        } else if (numeroSorteado.equals(getCartela().getNumero4())) {
            getCartela().setNumero4Sorteado(true);
        }
        atualizar();
    }

    public void notificarEncerramento() {
        getCartela().setBingoEncerrado(true);
        atualizar();
    }

    private void atualizar() {
        repository.save(getCartela());
    }

    public boolean bateu() {
        return getCartela().isNumero1Sorteado()
                    && getCartela().isNumero2Sorteado()
                    && getCartela().isNumero3Sorteado()
                    && getCartela().isNumero4Sorteado();
    }

}
