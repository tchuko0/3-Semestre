package sptech.projetoobserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoObserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoObserverApplication.class, args);
	}

}
