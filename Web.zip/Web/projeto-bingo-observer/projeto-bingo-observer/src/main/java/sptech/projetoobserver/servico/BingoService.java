package sptech.projetoobserver.servico;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sptech.projetoobserver.dominio.Bingo;
import sptech.projetoobserver.dominio.Cartela;
import sptech.projetoobserver.repositorio.BingoRepository;
import sptech.projetoobserver.repositorio.CartelaRepository;
import sptech.projetoobserver.servico.observer.CartelaObserver;
import sptech.projetoobserver.servico.subject.BingoSubject;

import java.util.ArrayList;
import java.util.List;

@Service
public class BingoService {

    private List<BingoSubject> subjects = new ArrayList<>();

    @Autowired
    private CartelaRepository cartelaRepository;

    @Autowired
    private BingoRepository bingoRepository;

    public Bingo salvar(Bingo bingo) {
        if (bingo.getIdBingo() == null) {
            registrarBingo(bingo);
        }
        if (bingo.getNumerosSorteados() == null) {
            bingo.setNumerosSorteados("");
            // para evitar isso: null-88-12-54-33-4-8-51
        }
        bingoRepository.save(bingo);

        return bingo;
    }

    public boolean inscreverCartelaEmBingo(
            int idCartela,
            int idBingo
    ) {
        if (!cartelaRepository.existsById(idCartela)) {
            return false;
        }
        if (!bingoRepository.existsById(idBingo)) {
            return false;
        }

        Cartela cartela = cartelaRepository
                .getReferenceById(idCartela);

        Bingo bingo = bingoRepository
                .getReferenceById(idBingo);

        BingoSubject subject = getSubjectPorBingo(bingo);

        CartelaObserver observer =
                new CartelaObserver(cartela, cartelaRepository);

        subject.adicionar(observer);
        return true;
    }

    public void sortear(Bingo bingo) {
        BingoSubject subject = getSubjectPorBingo(bingo);
        subject.sortear();
        bingoRepository.save(subject.getBingo());
    }

    public List<Cartela> getCartelasBatidas(Bingo bingo) {
        BingoSubject subject = getSubjectPorBingo(bingo);
        return subject.getCartelasBatidas();
    }

    public List<Cartela> getCartelas(Bingo bingo) {
        BingoSubject subject = getSubjectPorBingo(bingo);
        return subject.getCartelas();
    }

    private void registrarBingo(Bingo bingo) {
        subjects.add(new BingoSubject(bingo));
    }

    private BingoSubject getSubjectPorBingo(Bingo bingo) {
        for (BingoSubject subject : subjects) {
            if (subject.getBingo().getIdBingo().equals(bingo.getIdBingo())) {
                return subject;
            }
        }
        return null;
    }

}
