package sptech.projetoobserver.dominio;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Bingo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idBingo;

    private String premio;

    private String numerosSorteados;

    public Integer getIdBingo() {
        return idBingo;
    }

    public void setIdBingo(Integer idBingo) {
        this.idBingo = idBingo;
    }

    public String getPremio() {
        return premio;
    }

    public void setPremio(String premio) {
        this.premio = premio;
    }

    public String getNumerosSorteados() {
        return numerosSorteados;
    }

    public void setNumerosSorteados(String numerosSorteados) {
        this.numerosSorteados = numerosSorteados;
    }
}
