package sptech.projetoobserver.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.projetoobserver.dominio.Cartela;
import sptech.projetoobserver.repositorio.CartelaRepository;

import java.util.List;

@RestController
@RequestMapping("/cartelas")
public class CartelaController {

    @Autowired
    private CartelaRepository repository;

    @PostMapping
    public ResponseEntity<Cartela> post(
            @RequestBody Cartela novaCartela) {
        repository.save(novaCartela);
        return ResponseEntity.status(201).body(novaCartela);
    }

    @GetMapping
    public ResponseEntity<List<Cartela>> get() {
        List<Cartela> cartelas = repository.findAll();

        return cartelas.isEmpty()
                ? ResponseEntity.status(204).build()
                : ResponseEntity.status(200).body(cartelas);
    }

}
