package sptech.projetoobserver.servico.subject;

import sptech.projetoobserver.dominio.Bingo;
import sptech.projetoobserver.dominio.Cartela;
import sptech.projetoobserver.servico.observer.CartelaObserver;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

public class BingoSubject {

    private Bingo bingo;

    public BingoSubject(Bingo bingo) {
        this.bingo = bingo;
    }

    private List<CartelaObserver> observers = new ArrayList<>();

    public void adicionar(CartelaObserver novoObserver) {
        // só adiciona se não existir nenhum observer para
        // a mesma cartela neste Subject
        if (observers.stream()
            .noneMatch(observer ->
                observer.getCartela().getIdCartela()
                .equals(novoObserver.getCartela().getIdCartela())))
        {
            observers.add(novoObserver);

            notificarSorteiosJaRealizados(novoObserver);
        }
    }

    private void notificarSorteiosJaRealizados(
                                CartelaObserver observer) {
        String[] jaSorteados = getBingo()
                .getNumerosSorteados()
                .split("-");

        for (String sorteado : jaSorteados) {
            if (!sorteado.equals("")) {
                observer.notificarSorteio(
                        Integer.valueOf(sorteado));
            }
        }
    }

    public void remover(CartelaObserver observer) {
        observers.remove(observer);
    }

    public void removerTodos() {
        observers.clear();
    }

    public void sortear() {

        if (getContagemCartelasBatidas() > 0) {
            return;
        }

        // sorteando de 1 a 29 para sortear mais rápido
        int sorteado = ThreadLocalRandom.current()
                                        .nextInt(1, 30);

        // 88-12-54-33-4-8-51
        bingo.setNumerosSorteados(
                bingo.getNumerosSorteados()+"-"+sorteado);

        for (CartelaObserver observer: observers) {
            observer.notificarSorteio(sorteado);
        }

        if (getContagemCartelasBatidas() > 0) {
            for (CartelaObserver observer: observers) {
                observer.notificarEncerramento();
            }
        }
    }

    public long getContagemCartelasBatidas() {
        /*
        Contando quantos objetos do tipo CartelaObserver
        da lista "observers" possuem "bateu()" igual a true
        */
        long cartelasQueBateram = observers.stream()
                .filter(CartelaObserver::bateu)
                .count();

        return cartelasQueBateram;
    }

    public List<Cartela> getCartelasBatidas() {
        List<Cartela> cartelas = observers.stream()
                .filter(CartelaObserver::bateu)
                .map(CartelaObserver::getCartela)
                .collect(Collectors.toList());

        return cartelas;
    }

    public List<Cartela> getCartelas() {
        List<Cartela> cartelas = observers.stream()
                .map(CartelaObserver::getCartela)
                .collect(Collectors.toList());

        return cartelas;
    }

    public Bingo getBingo() {
        return bingo;
    }
}
