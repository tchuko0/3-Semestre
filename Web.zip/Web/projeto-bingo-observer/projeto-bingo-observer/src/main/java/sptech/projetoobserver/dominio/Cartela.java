package sptech.projetoobserver.dominio;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Cartela {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idCartela;

    private String dono;

    private Integer numero1;
    private Integer numero2;
    private Integer numero3;
    private Integer numero4;

    private boolean numero1Sorteado;

    private boolean numero2Sorteado;

    private boolean numero3Sorteado;

    private boolean numero4Sorteado;


    private boolean bingoEncerrado;

    public Integer getIdCartela() {
        return idCartela;
    }

    public void setIdCartela(Integer idCartela) {
        this.idCartela = idCartela;
    }

    public Integer getNumero1() {
        return numero1;
    }

    public void setNumero1(Integer numero1) {
        this.numero1 = numero1;
    }

    public Integer getNumero2() {
        return numero2;
    }

    public void setNumero2(Integer numero2) {
        this.numero2 = numero2;
    }

    public Integer getNumero3() {
        return numero3;
    }

    public void setNumero3(Integer numero3) {
        this.numero3 = numero3;
    }

    public Integer getNumero4() {
        return numero4;
    }

    public void setNumero4(Integer numero4) {
        this.numero4 = numero4;
    }

    public boolean isNumero1Sorteado() {
        return numero1Sorteado;
    }

    public void setNumero1Sorteado(boolean numero1Sorteado) {
        this.numero1Sorteado = numero1Sorteado;
    }

    public boolean isNumero2Sorteado() {
        return numero2Sorteado;
    }

    public void setNumero2Sorteado(boolean numero2Sorteado) {
        this.numero2Sorteado = numero2Sorteado;
    }

    public boolean isNumero3Sorteado() {
        return numero3Sorteado;
    }

    public void setNumero3Sorteado(boolean numero3Sorteado) {
        this.numero3Sorteado = numero3Sorteado;
    }

    public boolean isNumero4Sorteado() {
        return numero4Sorteado;
    }

    public void setNumero4Sorteado(boolean numero4Sorteado) {
        this.numero4Sorteado = numero4Sorteado;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public boolean isBingoEncerrado() {
        return bingoEncerrado;
    }

    public void setBingoEncerrado(boolean bingoEncerrado) {
        this.bingoEncerrado = bingoEncerrado;
    }

}
