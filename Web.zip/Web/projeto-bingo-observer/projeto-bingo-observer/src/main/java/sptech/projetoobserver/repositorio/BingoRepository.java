package sptech.projetoobserver.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.projetoobserver.dominio.Bingo;
import sptech.projetoobserver.dominio.Cartela;

public interface BingoRepository extends
                            JpaRepository<Bingo, Integer> {
}
