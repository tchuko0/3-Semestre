package sptech.projetoobserver.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.projetoobserver.dominio.Bingo;
import sptech.projetoobserver.dominio.Cartela;
import sptech.projetoobserver.repositorio.BingoRepository;
import sptech.projetoobserver.servico.BingoService;

import java.util.List;

@RestController
@RequestMapping("/bingos")
public class BingoController {

    @Autowired
    private BingoRepository repository;

    @Autowired
    private BingoService service;

    @PostMapping
    public ResponseEntity<Bingo> post(
            @RequestBody Bingo novoBingo) {
        service.salvar(novoBingo);
        return ResponseEntity.status(201).body(novoBingo);
    }

    @GetMapping
    public ResponseEntity<List<Bingo>> get() {
        List<Bingo> bingos = repository.findAll();

        return bingos.isEmpty()
                ? ResponseEntity.status(204).build()
                : ResponseEntity.status(200).body(bingos);
    }


    @PostMapping("/{idBingo}/inscricao-cartela/{idCartela}")
    public ResponseEntity<Bingo> post(@PathVariable int idBingo,
                                      @PathVariable int idCartela) {
        if (service.inscreverCartelaEmBingo(idCartela, idBingo)) {
            return ResponseEntity.status(201).build();
        }
        return ResponseEntity.status(404).build();
    }

    @PostMapping("/{idBingo}/sorteio")
    public ResponseEntity<Bingo> post(@PathVariable int idBingo) {
        if (!repository.existsById(idBingo)) {
            return ResponseEntity.status(404).build();
        }

        Bingo bingo = repository.findById(idBingo).get();
        service.sortear(bingo);

        return ResponseEntity.status(201).body(bingo);
    }

    @GetMapping("/{idBingo}/cartelas-batidas")
    public ResponseEntity<List<Cartela>> getBatidas(
            @PathVariable int idBingo) {
        if (!repository.existsById(idBingo)) {
            return ResponseEntity.status(404).build();
        }
        List<Cartela> cartelas = service.getCartelasBatidas(
                repository.getReferenceById(idBingo));

        return cartelas.isEmpty()
                ? ResponseEntity.status(204).build()
                : ResponseEntity.status(200).body(cartelas);
    }

    @GetMapping("/{idBingo}/cartelas")
    public ResponseEntity<List<Cartela>> getCartelas(
            @PathVariable int idBingo) {
        if (!repository.existsById(idBingo)) {
            return ResponseEntity.status(404).build();
        }
        List<Cartela> cartelas = service.getCartelas(
                repository.getReferenceById(idBingo));

        return cartelas.isEmpty()
                ? ResponseEntity.status(204).build()
                : ResponseEntity.status(200).body(cartelas);
    }

}
