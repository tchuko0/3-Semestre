package sptech.projetoobserver.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.projetoobserver.dominio.Cartela;

public interface CartelaRepository extends
                            JpaRepository<Cartela, Integer> {

}
