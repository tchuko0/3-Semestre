package com.example.atividade2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
