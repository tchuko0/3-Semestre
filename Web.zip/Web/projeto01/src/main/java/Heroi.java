public class Heroi {
    // classes wrapper
    String nome;
    String cpf;
    Integer idade;
    Double peso;
    Boolean vivo;

    public Boolean getVivo() {
        return vivo;
    }
}
