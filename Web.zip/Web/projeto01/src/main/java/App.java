public class App {
    public static void main(String[] args) {
        System.out.println("é nois corinthians");

        Heroi h1 = new Heroi();
        System.out.println("Idade: "+h1.idade);

        HeroiTiposPrimitivos h2 = new HeroiTiposPrimitivos();
        System.out.println("Idade: " +h2.idade);
        System.out.println("Peso: " +h2.peso);
        System.out.println("É Vivo ? : " +h2.vivo);

        Integer inteiro1 = null;
        System.out.println(inteiro1);

//        tipos primitivos quando são variaveis locais precisam ser inicializados ates de serem usados

//        int inteiro2 ; // variavel local
//        System.out.println(inteiro2);
    }
}
