public class HeroiTiposPrimitivos {

    // os atributos abaixo usam TIPOS PRIMITIVOS (não são classes) eles não tem atributos nem metodos
    // eles só tem o valor em si
    // eles tem sem pre um valor padrao quando são atributos de instancia


    String nome;
    String cpf;
    int idade; // padrão 0
    double peso; // padrao 0.0
    boolean vivo; // padrao false

    /*
    * para booleanos o padrão ""get/set tbm pode começar com id ou has
    ex: isVivo
    *
    * para tipos primitivos é mais comum o "is" do que o "get"
    * */

    public boolean isVivo() {
        return vivo;
    }
}
