package sptech.projetojparelacionamentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoJpaRelacionamentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoJpaRelacionamentosApplication.class, args);
	}

}
