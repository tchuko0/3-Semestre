package sptech.projetojparelacionamentos.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.projetojparelacionamentos.dominio.Pais;
import sptech.projetojparelacionamentos.repositorio.PaisRepositorio;

import java.util.List;

@RestController
@RequestMapping("/paises")
// public class PaisResource {
public class PaisController {

    @Autowired
    private PaisRepositorio repositorio;

    @GetMapping
    public ResponseEntity<List<Pais>> get() {
        return ResponseEntity.status(200).body(repositorio.findAll());
    }

    @PostMapping
    public ResponseEntity<Pais> post(@RequestBody Pais novoPais) {
        repositorio.save(novoPais);
        return ResponseEntity.status(201).body(novoPais);
    }

    @GetMapping("/cont")
    public ResponseEntity<List<Pais>> getContinente() {
        return ResponseEntity.status(200).body(repositorio.findByContinenteIdContinente(5));
    }

    @GetMapping("/por-nome")
    public ResponseEntity<List<Pais>> getPorNome(){
        return ResponseEntity.status(200).body(repositorio.findByContinenteNome("Brasil"));
    }

    @GetMapping("/id-continente/{idContinente}")
    public ResponseEntity<List<Pais>> getContinente(@PathVariable int idContinente){
        return ResponseEntity.status(200).body(repositorio.findByContinenteIdContinente(idContinente));
    }

    @GetMapping("/nome-continente/{nomeContinente}")
    public ResponseEntity<List<Pais>> get(@PathVariable String nomeContinente){
        return ResponseEntity.status(200).body(repositorio.findByContinenteNomeContains(nomeContinente));
    }



}



