package sptech.projetojparelacionamentos.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.projetojparelacionamentos.dominio.Pais;

import java.util.List;

public interface PaisRepositorio extends
                                    JpaRepository<Pais, Integer> {

    List<Pais> findByContinenteIdContinente(int idContinente);

    List<Pais> findByContinenteNome(String nome);
    List<Pais> findByContinenteNomeContains(String nome);

}
