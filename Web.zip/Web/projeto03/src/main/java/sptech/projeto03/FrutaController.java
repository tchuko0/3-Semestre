package sptech.projeto03;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/frutas")
public class FrutaController {

    private List<Fruta> frutas = new ArrayList<>();


    @PostMapping
    public ResponseEntity<Fruta> post(@RequestBody Fruta novaFruta){
        frutas.add(novaFruta);
        return ResponseEntity.status(201).body(novaFruta);
    }

    @GetMapping
    public ResponseEntity<List<Fruta>> get(){
        if (frutas. isEmpty()){
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(frutas);
    }

    @GetMapping("/{posicao}")
    public ResponseEntity<Fruta> get(@PathVariable int posicao){

            if (posicao < 0 || posicao > frutas.size()){
                return ResponseEntity.status(404).build();
            }

        return ResponseEntity.status(200).body(frutas.get(posicao));
    }
}
