package sptech.projeto03;

import java.math.BigDecimal;
import java.util.UUID;

public class Fruta {

    private UUID id = UUID.randomUUID();

    private String nome;

    // bigdacimal é o melhor quando vamos mexer com dinheiro
    private BigDecimal preco;

    public UUID getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public BigDecimal getPreco() {
        return preco;
    }
}
