insert into continente (nome) values
('África'),('América'),('Europa'),
('Ásia'),('Oceania');

insert into pais
(nome, populacao, continente_id_continente)
values
('Nigéria', 10000, 1),
('Egito', 20000, 1),
('Japão', 15000, 4),
('China', 100000, 4),
('Brasil', 15000, 2),
('Itália', 100000, 3);
