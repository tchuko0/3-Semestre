package sptech.projetojparelacionamentos.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.projetojparelacionamentos.dominio.Pais;
import sptech.projetojparelacionamentos.repositorio.PaisRepositorio;

import java.util.List;

@RestController
@RequestMapping("/paises")
// public class PaisResource {
public class PaisController {

    @Autowired
    private PaisRepositorio repositorio;

    @GetMapping
    public ResponseEntity<List<Pais>> get(@RequestParam(required = false)String nome,
                                          @RequestParam(required = false)Integer populacao) {
        if (nome != null && populacao != null){
            return ResponseEntity.status(200).body(repositorio.findByNomeContainsAndPopulacaoGreaterThan(nome,populacao));
        }

        if (nome != null){
            return ResponseEntity.status(200).body(repositorio.findByNomeContains(nome));
        }

        if (populacao != null){
            return ResponseEntity.status(200).body(repositorio.findByPopulacaoGreaterThan(populacao));
        }
        return ResponseEntity.status(200).body(repositorio.findAll());
    }

    /*
No JSON de "continente" basta passar o "idContinente", que é seu Id.
ex:
{
    "nome": "Colômbia",
    "contiente": {
        "idContiente": 2
    }
}
     */
    @PostMapping
    public ResponseEntity<Pais> post(@RequestBody Pais novoPais) {
        repositorio.save(novoPais);
        return ResponseEntity.status(201).body(novoPais);
    }

    @GetMapping("/id-continente/{idContinente}")
    public ResponseEntity<List<Pais>> getPorContinente(
            @PathVariable int idContinente
    ) {
        List<Pais> paises =
        repositorio.findByContinenteIdContinente(idContinente);

        return paises.isEmpty()
                ? ResponseEntity.status(204).build()
                : ResponseEntity.status(200).body(paises);
    }

    @GetMapping("/nome-continente/{nomeContinente}")
    public ResponseEntity<List<Pais>> getPorContinente(
            @PathVariable String nomeContinente
    ) {
        List<Pais> paises =
        repositorio.findByContinenteNomeContains(nomeContinente);

        return paises.isEmpty()
                ? ResponseEntity.status(204).build()
                : ResponseEntity.status(200).body(paises);
    }
}



