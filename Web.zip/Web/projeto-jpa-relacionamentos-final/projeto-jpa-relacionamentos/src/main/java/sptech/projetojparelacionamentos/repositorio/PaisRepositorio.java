package sptech.projetojparelacionamentos.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.projetojparelacionamentos.dominio.Pais;

import java.util.List;

public interface PaisRepositorio extends
                                    JpaRepository<Pais, Integer> {
/*
Dynamic Finders com relacionamentos:
Citamos primeiro o nome do atributo e depois o nome do do atributo na entidade relacionada
 */

    /*
findBy -> tipo de Finder (consulta)
Contiente -> busca no atributo "contiente"
IdContiente -> busca no atributo "idContinente" da classe Continente
     */
    List<Pais> findByContinenteIdContinente(int idContinente);


    List<Pais> findByNomeContains(String nome);

    List<Pais> findByContinenteNomeContains(String nome);

    List<Pais> findByContinenteNome(String nome);

    List<Pais> findByPopulacaoGreaterThan(int populacao);

    List<Pais> findByNomeContainsAndPopulacaoGreaterThan(String nome, int populacao);

}
