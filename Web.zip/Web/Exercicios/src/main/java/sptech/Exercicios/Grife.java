package sptech.Exercicios;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Grife {

    private String nome;
    private int anoCriacao;
    private Double acaoBolsa;
    private String chaveAcesso;

    public Grife(String nome, int anoCriacao, Double acaoBolsa, String chaveAcesso) {
        this.nome = nome;
        this.anoCriacao = anoCriacao;
        this.acaoBolsa = acaoBolsa;
        this.chaveAcesso = chaveAcesso;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {

        this.nome = nome;
    }

    public int getAnoCriacao() {

        return anoCriacao;
    }

    public void setAnoCriacao(int anoCriacao)
    {
        this.anoCriacao = anoCriacao;
    }

    public double getAcaoBolsa()
    {
        return acaoBolsa;
    }

    public void setAcaoBolsa(double acaoBolsa) {
        this.acaoBolsa = acaoBolsa;
    }

    public String chaveDeAcesso(){

        return chaveAcesso;
    }

    public void setChaveAcesso(String chaveAcesso) {

        this.chaveAcesso = chaveAcesso;
    }
}
