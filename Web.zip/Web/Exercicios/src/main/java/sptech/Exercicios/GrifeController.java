package sptech.Exercicios;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/grifes")
public class GrifeController {

    private List<Grife> grifes = new ArrayList<>();
    private List<Grife> populares = new ArrayList<>();


    @PostMapping
    public Grife postGrife(@RequestBody Grife novaGrife) {
        if (novaGrife != null) {
            grifes.add(novaGrife);

        }
        return novaGrife;
    }

    @GetMapping("/{posicao}/cotas/{quantidade}/{chaveAcesso}")
    public Double getCota(@PathVariable int posicao,
                                 @PathVariable int quantidade,
                                 @PathVariable String chaveAcesso){

        if(posicao >= 0 && posicao < grifes.size()){

            if(grifes.get(posicao).chaveDeAcesso().equals(chaveAcesso)){

                return (double) grifes.get(posicao).getAcaoBolsa()* quantidade;

            }
        }

        return null;
    }

    @GetMapping("/populares")
    public List<Grife> getPopulares(){
        for(Grife grife : grifes){
            if(grife.getAcaoBolsa() < 15){
                populares.add(grife);
            }
        }
        return populares;
    }

    @GetMapping
    public List<Grife> getGrifes(){

        return grifes;
    }

    @PutMapping("/{posicao}")
    public Grife putGrife(@PathVariable int posicao, @RequestBody Grife grife){
        if(posicao >= 0 && posicao < grifes.size()){
            grifes.set(posicao,grife);
        }
        return grife;
    }

    @DeleteMapping("/{posicao}")
    public String deleteGrife(@PathVariable int posicao){
        String mensagem = "Erro ao remover";
        if(posicao >= 0 && posicao < grifes.size()){
            grifes.remove(posicao);
            mensagem = "Grife removida com sucesso";
        }
        return mensagem;
    }




}
