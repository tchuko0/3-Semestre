package sptech.Exercicios;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/lutadores")
public class LutadoresController {

    private List<Lutadores> lutadores = new ArrayList<>();
    private List<Lutadores> sobreviventes = new ArrayList<>();
    @PostMapping
    public Lutadores postLutadores(@RequestBody Lutadores lutador){
        lutadores.add(lutador);
        return lutador;
    }

    @GetMapping
    public List<Lutadores> getLutadores(){
        return lutadores;
    }

    @PatchMapping("/{posicaoBate}/golpe/{posicaoApanha}")
    public List<Lutadores> patchLutadores(@PathVariable int posicaoBate,
                                          @PathVariable int posicaoApanha){
        List<Lutadores> lutadoresBrigando = new ArrayList<>();

        if(posicaoApanha >= 0 && posicaoApanha < lutadores.size()){
            if (posicaoBate >= 0 && posicaoBate < lutadores.size()){

                int golpe = lutadores.get(posicaoBate).getForcaGolpe() - lutadores.get(posicaoApanha).getForcaDefesa();
                lutadores.get(posicaoApanha).setVida(lutadores.get(posicaoApanha).getVida() - golpe);
                if(lutadores.get(posicaoApanha).getVida() < 0){
                    lutadores.get(posicaoApanha).setVida(0);
                }
            }
        }

        return lutadores;
    }

    @GetMapping("/sobreviventes")
    public List<Lutadores> getSobreviventes(){

        for(Lutadores lutador : lutadores){
            if(lutador.getVida() > 0){
                sobreviventes.add(lutador);
            }
        }
        return sobreviventes;
    }
}
